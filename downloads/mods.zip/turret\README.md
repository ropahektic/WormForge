Dynamite slot. Space plants a persist LuaActor the same way a mine is placed.

Line of sight is `wa.land.trace`. A round is `worm:hurt` plus a shove along the bore, not a stock blast. It only tracks worms that moved last tick. Empty clip: keep sweeping, refill when the planter’s turn starts.

Each team colour × idle/firing pose is one 120-frame GIF (`a:frame` is the 360° aim). Needs no other dynamite overlay.
