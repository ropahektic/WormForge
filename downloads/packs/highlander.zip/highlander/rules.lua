-- Highlander, on Project X's weapon layout.
--
-- A port of Project X's `scheme_hl_0rang3` (Highlander 0rang3 1.1). Every
-- worm is dealt one weapon from each of three pools at the start of the match.
-- Only the worm whose turn it is may use its weapons, one shot of each per
-- turn. Kill a worm and you take everything it carried.
--
-- The scheme puts each of its weapons on one of WA's 71 stock slots: the
-- Baseball Bat on the girder's, the Cluster Bomb on the magic bullet's, and
-- so on. The pools below are PX's own lists, in PX's order, each weapon
-- written as the stock slot it takes. A weapon not ported yet leaves WA's
-- stock weapon on its slot, and that stands in for it.
--
-- The source (`highlander.txt`) does all of this with four calls:
-- SetWeaponEx(team, weapon, 1) to grant and SetWeaponEx(team, weapon, 0) to
-- take away. `worm:ammo(name, { set = n })` is the same absolute write. It has
-- to be absolute: a stock scheme gives some of these weapons infinite ammo,
-- and adding to infinite leaves it infinite.
--
-- Where this differs from the source, on purpose:
--
--   * No turn-end removal. PX removes a worm's weapons at M_TURNEND and again,
--     through CurW, at the next M_TURNBEGIN. The second alone is enough, so
--     this listens for one message instead of two.
--
--     START_TURN (0x34) reaches only the worm whose turn it is: WA's handler
--     marks the receiver turn-active and calls TeamArena::SetActiveWorm on it
--     unconditionally (OpenWA `msg_start_turn`), which would be nonsense sent
--     to every worm. So the worm it arrives on IS the active worm.
--
--   * Every pooled slot is zeroed for every team at each turn start, not
--     just the previous worm's. PX relied on its scheme having those slots at
--     zero. Here the scheme can say anything, so the pack enforces it itself.
--
--   * PX's GiveWeapons also sets the Hot Air Balloon to 3 and the Wind
--     Changer to 1 each turn; so does start_turn.
--
-- Lockstep: dealing, turn_start and death are all dispatched from WA's own
-- simulation messages, and every random choice is wa.random(). Two peers, or
-- a peer and a replay, deal the same hands and make the same grants. Nothing
-- here reads local input or the clock.

-- ---------------------------------------------------------------- weapons

-- PX's sprite builder, for the weapons below whose hold PX draws at run
-- time: the worm posture with no weapon in it, and its hands. The helper
-- further down draws the weapon and a hand over it.
local PX_POSTURE = {
  weaponlnk = "sprites/px_hold/aim", weaponlnku = "sprites/px_hold/aimu",
  weaponlnkd = "sprites/px_hold/aimd",
  wthrow = "sprites/px_hold/draw", wthrowu = "sprites/px_hold/drawu",
  wthrowd = "sprites/px_hold/drawd",
}
local PX_HANDS = {
  "sprites/px_hold/hand_rad_lower", "sprites/px_hold/hand_rad", "sprites/px_hold/hand_rad_upper",
}
-- Filled in by the Double Bazooka's and Nuke Rocket's sections further down.
local double_bazooka_explode
local nuke_rocket_explode
local chilli_bomb_explode
local jump_fire
-- Ported weapons. Each takes its scheme record, cut from the .pxs with
-- tools/px_scheme_weps.py: how it fires, and its PX name. Anything else in an
-- entry goes to wa.weapons.replace as it is.
--
-- WA's own weapons, as PX tuned them for this scheme. One moved off its own
-- stock slot borrows its own stock icon.
local PORTED = {
  { weapon = "dynamite" },
  { weapon = "blow_torch" },                                   -- BlowTorch
  { weapon = "flame_thrower" },
  { weapon = "girder", panel_icon = "baseball_bat" },          -- Baseball Bat
  { weapon = "girder_pack" },                                  -- 3 Girder Pack
  { weapon = "fast_walk" },
  { weapon = "crate_spy" },
  { weapon = "crate_shower" },
  { weapon = "magic_bullet", panel_icon = "cluster_bomb" },    -- Cluster Bomb
  { weapon = "invisibility", panel_icon = "teleport" },        -- Teleport
  { weapon = "damage_x2", panel_icon = "skunk" },              -- Skunk
  { weapon = "double_turn_time", panel_icon = "mole_bomb" },   -- Mole Bomb
  { weapon = "ming_vase" },                                    -- Priceless Ming Vase
}

-- PX weapons that need only PX's art: its icons, copied byte for byte so
-- replays share them, and its strips split into frame folders with
-- tools/px_split_strip.py. Where PX draws the worm's hold at run time with
-- its sprite builder (p_sprite_builder), so does the pack (PX_HOLDS below).
local PX_ART = {
  { -- Double Bazooka: a second shell carries on from where the first
    -- explodes (its section below). Held as a plain bazooka: the pack's
    -- record has launcher 3 (wbaz) at +0x34 where the scheme's has 7, the
    -- homing missile's recoloured wbaz2 (Weapon__hold_sheet, 0x51C060).
    weapon = "bazooka",
    panel_icon = "sprites/double_bazooka/double_bazooka_ico.png",
    on_explode = function(ev) double_bazooka_explode(ev) end,
  },
  { -- Nuke Rocket: a rocket fuses on the ground, then a nuke climbs out of
    -- it (its section below). PX draws both upright (a type 5 WeapSprite,
    -- mirrored flying left), as WA draws a flight sprite.
    weapon = "mine",
    panel_icon = "sprites/nuke_rocket/nuke_rocket_ico.png",
    sprite = "sprites/nuke_rocket/nuke_rocket_bullet.png",
    on_explode = function(ev) nuke_rocket_explode(ev) end,
    -- The worm holds it as PX's sprite builder draws it (PX_HOLDS below):
    -- the record's own sprite is PX-only, which left WA no sheet to draw
    -- the worm with.
    worm_sprites = PX_POSTURE,
    sprites = {
      "sprites/px_hold/nuke_rocket", PX_HANDS[1], PX_HANDS[2], PX_HANDS[3],
    },
    sounds = { "sounds/nuke_rocket_launch.wav" },
    params = { gpu_prefix = "sprites/px_hold/" },
  },
  { -- Burning Sheep Launcher
    weapon = "sheep_launcher",
    panel_icon = "sprites/launchers/burning_sheep_launcher_ico.png",
  },
  { -- Cow Launcher
    weapon = "mad_cow",
    panel_icon = "sprites/launchers/cow_launcher_ico.png",
  },
  { -- Old Woman Launcher. Its record is PX's but for one field: +0x34,
    -- which picks a projectile's aim sheet in WA (0x51C060), is 3 (the
    -- bazooka hold, as the Cow Launcher's) where PX has 0. WA knows 1-12
    -- only and draws no worm at all for 0.
    weapon = "old_woman",
    panel_icon = "sprites/launchers/old_woman_launcher_ico.png",
  },
  { -- Pigeon Strike
    weapon = "mail_strike",
    panel_icon = "sprites/pigeon_strike/ico_pigeonst.png",
  },
  { -- Windy Cluster: the stock cluster bomb's body, PX's bits.
    weapon = "cluster_bomb",
    panel_icon = "sprites/windy_cluster/ico_windyc.png",
    cluster = { sprite = "sprites/windy_cluster/cluster" },
  },
  { -- Super Gravedigger, and the worm holding and taking it out.
    weapon = "banana_bomb",
    panel_icon = "sprites/super_gravedigger/sgrave_ico.png",
    sprite = "sprites/super_gravedigger/flight",
    cluster = { sprite = "sprites/super_gravedigger/cluster" },
    worm_sprites = {
      weaponlnk = "sprites/super_gravedigger/aim",
      weaponlnku = "sprites/super_gravedigger/aimu",
      weaponlnkd = "sprites/super_gravedigger/aimd",
      wthrow = "sprites/super_gravedigger/draw",
      wthrowu = "sprites/super_gravedigger/drawu",
      wthrowd = "sprites/super_gravedigger/drawd",
    },
  },
  -- The next three have trails PX draws by overriding stock sprites its
  -- records point at: the Salvation Army's wsv* frames, free here because
  -- the Ferret holds that slot. sprite_overrides does the same, for the
  -- whole match. The trail art is PX's sprite_curtis_<id> libraries'.
  { -- S.M.A.R.T Bomb: its bits home, and draw their own sprite doing so.
    weapon = "mortar",
    panel_icon = "sprites/smart_bomb/smart_ico.png",
    sprite = "sprites/smart_bomb/flight",
    cluster = {
      sprite = "sprites/smart_bomb/cluster",
      homing_sprite = "sprites/smart_bomb/cluster_homing",
    },
    sprite_overrides = { wsvbd = "sprites/smart_bomb/trail" },          -- 250
    worm_sprites = {
      weaponlnk = "sprites/smart_bomb/aim",
      weaponlnku = "sprites/smart_bomb/aimu",
      weaponlnkd = "sprites/smart_bomb/aimd",
      wthrow = "sprites/smart_bomb/draw",
      wthrowu = "sprites/smart_bomb/drawu",
      wthrowd = "sprites/smart_bomb/drawd",
    },
  },
  { -- Blaster Worm
    weapon = "homing_pigeon",
    panel_icon = "sprites/blaster_worm/bworm_ico.png",
    sprite = "sprites/blaster_worm/flight",
    cluster = { sprite = "sprites/blaster_worm/cluster" },
    sprite_overrides = { wsvbu = "sprites/blaster_worm/cluster_trail" }, -- 249
    worm_sprites = {
      weaponlnk = "sprites/blaster_worm/aim",
      weaponlnku = "sprites/blaster_worm/aimu",
      weaponlnkd = "sprites/blaster_worm/aimd",
      wthrow = "sprites/blaster_worm/draw",
      wthrowu = "sprites/blaster_worm/drawu",
      wthrowd = "sprites/blaster_worm/drawd",
    },
  },
  { -- Thumper Nade
    weapon = "battle_axe",
    panel_icon = "sprites/thumper_nade/thumpern_ico.png",
    sprite = "sprites/thumper_nade/flight",
    cluster = { sprite = "sprites/thumper_nade/cluster" },
    sprite_overrides = {
      wsvg = "sprites/thumper_nade/trail",                                -- 251
      wsvgu = "sprites/thumper_nade/cluster_trail",                       -- 252
    },
    worm_sprites = {
      weaponlnk = "sprites/thumper_nade/aim",
      weaponlnku = "sprites/thumper_nade/aimu",
      weaponlnkd = "sprites/thumper_nade/aimd",
      wthrow = "sprites/thumper_nade/draw",
      wthrowu = "sprites/thumper_nade/drawu",
      wthrowd = "sprites/thumper_nade/drawd",
    },
  },
  -- Strikes keep their bomb's art 0x14 further along than a projectile
  -- does; `sprite` and `cluster.sprite` follow it there.
  { -- Thumper Nade Strike: Thumper Nades from the sky, with the Thumper
    -- Nade's own trails (the overrides above).
    weapon = "carpet_bomb",
    panel_icon = "sprites/thumper_nade/thumpernst_ico.png",
    sprite = "sprites/thumper_nade/flight",
    cluster = { sprite = "sprites/thumper_nade/cluster" },
  },
  { -- Mortar Strike: stock mortar shells, PX's trails and bits.
    weapon = "air_strike",
    panel_icon = "sprites/mortar_strike/ico_mortarst.png",
    cluster = { sprite = "sprites/mortar_strike/cluster" },
    sprite_overrides = {
      wsvclnk = "sprites/mortar_strike/trail",                             -- 466
      wsvc = "sprites/mortar_strike/cluster_trail",                        -- 260
    },
  },
  { -- Gravler: a mole bomb whose records point its dive and dig frames at
    -- the Salvation Army's wsvr*/wsvb, which PX's script overrides.
    weapon = "mole_bomb",
    panel_icon = "sprites/gravler/gravler_ico.png",
    sprite_overrides = {
      wsvr = "sprites/gravler/gravlerdive",                                -- 245
      wsvru = "sprites/gravler/gravlerdiga",                               -- 246
      wsvrd = "sprites/gravler/gravlerdigb",                               -- 247
      wsvb = "sprites/gravler/gravlerdigc",                                -- 248
    },
    worm_sprites = {
      weaponlnk = "sprites/gravler/aim",
      weaponlnku = "sprites/gravler/aimu",
      weaponlnkd = "sprites/gravler/aimd",
      wthrow = "sprites/gravler/draw",
      wthrowu = "sprites/gravler/drawu",
      wthrowd = "sprites/gravler/drawd",
    },
  },
  { -- Gravler Strike: its record points at the same four frames, so the
    -- Gravler's overrides draw it.
    weapon = "mole_squadron",
    panel_icon = "sprites/gravler/gravlerst_ico.png",
  },
  { -- Ghost Sheep: the Aqua Sheep's own sprites, overridden.
    weapon = "aqua_sheep",
    panel_icon = "sprites/ghost_sheep/ghost_sheep_ico.png",
    sprite_overrides = {
      aquashp1 = "sprites/ghost_sheep/ghstshp1",                           -- 156
      aquashp2 = "sprites/ghost_sheep/ghstshp2",                           -- 157
    },
  },
  { -- Pogo Sheep. Its bits' trail is the Blaster Worm's (249, above).
    weapon = "sheep",
    panel_icon = "sprites/pogo_sheep/psheep_ico.png",
    sprite = "sprites/pogo_sheep/flight",
    cluster = { sprite = "sprites/pogo_sheep/cluster" },
  },
  { -- Banana Express: stock banana bombs from PX's banana plane. PX's
    -- record names its plane 704, an id PX adds past WA's sprites; `plane`
    -- gives the strike the sheet instead.
    weapon = "mb_bomb",
    panel_icon = "sprites/banana_express/banana_express_ico.png",
    plane = "sprites/banana_express/plane",
  },
  { -- Real Shotgun: PX's FireFinal fires the shotgun five times per shot,
    -- five pellets in one frame, each spread by WA's own hitscan cone.
    weapon = "shotgun",
    panel_icon = "sprites/real_shotgun/real_shotgun_ico.png",
    fire_repeat = 5,
  },
  { -- Hellish Hand-Grenade: the hellish_grenade example's art on the scheme's
    -- record, which leaves the flight sprite to the slot.
    weapon = "holy_grenade",
    panel_icon = "sprites/hellish/hhh_ico.png",
    sprite = "sprites/hellish/grenade",
    worm_sprites = {
      weaponlnk = "sprites/hellish/aim",
      weaponlnku = "sprites/hellish/aimu",
      weaponlnkd = "sprites/hellish/aimd",
      wthrow = "sprites/hellish/draw",
      wthrowu = "sprites/hellish/drawu",
      wthrowd = "sprites/hellish/drawd",
    },
  },
  { -- Remote Roller
    weapon = "skunk",
    panel_icon = "sprites/remote_roller/rroller_ico.png",
    sprite = "sprites/remote_roller/flight",
    worm_sprites = {
      weaponlnk = "sprites/remote_roller/aim",
      weaponlnku = "sprites/remote_roller/aimu",
      weaponlnkd = "sprites/remote_roller/aimd",
      wthrow = "sprites/remote_roller/draw",
      wthrowu = "sprites/remote_roller/drawu",
      wthrowd = "sprites/remote_roller/drawd",
    },
  },
  { -- Igniter: PX sets the missile's own sprite to 0 and draws its bullet at
    -- run time, animated and turned to its flight (PX_WEAP_SPRITES below).
    -- WA still draws its homing missile's rocket under it for now.
    weapon = "homing_missile",
    panel_icon = "sprites/igniter/igniter_ico.png",
    worm_sprites = PX_POSTURE,
    sprites = {
      "sprites/px_hold/igniter", PX_HANDS[1], PX_HANDS[2], PX_HANDS[3], "sprites/igniter/flight",
    },
    params = { gpu_prefix = "sprites/" },
  },
  { -- Chilli Bomb: five more Chillis burst out of it, which burst into fire
    -- (its section below). PX's record has sprite 0 and PX draws the chilli
    -- at run time, turned to its flight (PX_WEAP_SPRITES below). A thrown
    -- weapon's worm posture is picked by its sprite, so the record keeps the
    -- banana, and each missile's own copy is set to 0 in flight instead.
    weapon = "super_banana",
    panel_icon = "sprites/chilli_bomb/chilli_ico.png",
    sprite = "banana",
    on_explode = function(ev) chilli_bomb_explode(ev) end,
    worm_sprites = PX_POSTURE,
    sprites = { "sprites/px_hold/chilli_bomb", PX_HANDS[1], PX_HANDS[2], PX_HANDS[3] },
    params = { gpu_prefix = "sprites/px_hold/" },
  },
  { -- Sticky Bomb: PX's record leaves the bomb's sprite 0 and PX's script
    -- draws the bomb at run time. Here the bomb is the stock grenade sprite
    -- again -- a grenade-type slot picks the worm's throw sheet from it, and
    -- 0 has none -- which the override draws as PX's bomb. The bits too.
    weapon = "grenade",
    panel_icon = "sprites/sticky_bomb/sbico.png",
    sprite = "grenade",
    cluster = { sprite = "sprites/sticky_bomb/bomb" },
    -- Stuck, the bits draw with the frames at +0x178..+0x184, which the
    -- record points at the Salvation Army's 467; PX overrides that too.
    sprite_overrides = {
      grenade = "sprites/sticky_bomb/bomb",                                -- 50
      wsvclnku = "sprites/sticky_bomb/bomb",                               -- 467
    },
    worm_sprites = PX_POSTURE,
    sprites = { "sprites/px_hold/sticky_bomb", PX_HANDS[1], PX_HANDS[2], PX_HANDS[3] },
    params = { gpu_prefix = "sprites/px_hold/" },
  },
  { -- Fire Jump: a fire punch, then a jump and a glide (below).
    weapon = "fire_punch",
    panel_icon = "sprites/fire_jump/fire_jump_ico.png",
  },
  { -- Super Drill: WA's drill, cutting a second hole each frame (below).
    weapon = "pneumatic_drill",
    panel_icon = "sprites/super_drill/ico_superdrill.png",
  },
  { -- Shadow-Bolt: the record leaves the bolt's sprite 0, and PX draws the
    -- bolt at run time, animated and turned to its flight (PX_WEAP_SPRITES
    -- below), with its trail on stock 453 (sprite_curtis_453).
    weapon = "longbow",
    panel_icon = "sprites/shadow_bolt/ico_shadowb.png",
    worm_sprites = PX_POSTURE,
    sprite_overrides = { [453] = "sprites/shadow_bolt/trail" },
    sprites = { "sprites/px_hold/shadow_bolt", "sprites/shadow_bolt/bolt" },
    params = { gpu_prefix = "sprites/" },
  },
  { -- Hot Air Balloon: WA's parachute, carried up by PX's script (below).
    weapon = "bungee",
    panel_icon = "sprites/balloon/balloon_icon.png",
    sprites = { "sprites/balloon/balloon", "sprites/balloon/basket" },
    -- A pack WAV plays only once an entry registers it.
    sounds = {
      "sounds/balloon/inflate1.wav", "sounds/balloon/inflate2.wav", "sounds/balloon/inflate3.wav",
      "sounds/balloon/pop1.wav", "sounds/balloon/pop2.wav", "sounds/balloon/pop3.wav",
      "sounds/balloon/pop4.wav",
    },
    params = { gpu_prefix = "sprites/balloon/" },
  },
  { -- Hang-Glider: WA's parachute, flown as PX's glider (below).
    weapon = "parachute",
    panel_icon = "sprites/hang_glider/ico_glider.png",
    sprites = { "sprites/hang_glider/glider", "sprites/hang_glider/pack" },
    sounds = { "sounds/hang_glider/hangopen.wav", "sounds/hang_glider/hangclose.wav" },
    params = { gpu_prefix = "sprites/hang_glider/" },
  },
  { -- Swim Suit: on the laser sight's slot; worn, the worm swims (below).
    weapon = "laser_sight",
    panel_icon = "sprites/swim_suit/ico_swimsuit.png",
    sprites = { "sprites/swim_suit/swim", "sprites/swim_suit/float", "sprites/swim_suit/ring" },
    sounds = { "sounds/swim_suit/putting_on_ssuit.wav" },
    params = { gpu_prefix = "sprites/swim_suit/" },
  },
  { -- Jump: on the ninja rope's slot; the worm leaves with the shot (below).
    weapon = "ninja_rope",
    panel_icon = "sprites/jump/jumpic.png",
    worm_sprites = {
      weaponlnk = "sprites/jump/aim", weaponlnku = "sprites/jump/aimu",
      weaponlnkd = "sprites/jump/aimd",
    },
    on_fire = function(fire) jump_fire(fire) end,
  },
  { -- Wind Changer: on the surrender's slot; sets the wind (below).
    weapon = "surrender",
    panel_icon = "sprites/wind_changer/ico_windchanger.png",
    sounds = {
      "sounds/wind_changer/breeze.wav", "sounds/wind_changer/calm_wind.wav",
      "sounds/wind_changer/strong_wind.wav",
    },
  },
  { -- Gravity Control: on low gravity's slot; sets the gravity (below).
    weapon = "low_gravity",
    panel_icon = "sprites/gravity_control/gravity_control_ico.png",
    sounds = { "sounds/gravity_control/activate.wav", "sounds/gravity_control/error.wav" },
  },
  { -- Helicopter: WA's jet pack, flown by PX's script (below).
    weapon = "jet_pack",
    panel_icon = "sprites/helicopter/heli_ico.png",
    sprites = { "sprites/helicopter/flying", "sprites/helicopter/jumpin" },
    sounds = {
      "sounds/helicopter/helicopterloop.wav",
      "sounds/helicopter/1.wav", "sounds/helicopter/2.wav", "sounds/helicopter/3.wav",
      "sounds/helicopter/4.wav",
      "sounds/helicopter/oops1.wav", "sounds/helicopter/oops2.wav", "sounds/helicopter/huh.wav",
      "sounds/helicopter/poop.wav", "sounds/helicopter/idiot.wav",
    },
    params = { gpu_prefix = "sprites/helicopter/" },
  },
  { -- Sniper Rifle: the hold drawn at run time, PX's laser sight while aiming
    -- and its own shot (below). Firing, the worm takes the snipefire poses
    -- the scheme's record names (lit by the muzzle), not WA's handgun, and
    -- the hold and laser stay up over them (PX_HOLDS).
    weapon = "handgun",
    panel_icon = "sprites/sniper_rifle/srico.png",
    worm_sprites = {
      weaponlnk = PX_POSTURE.weaponlnk, weaponlnku = PX_POSTURE.weaponlnku,
      weaponlnkd = PX_POSTURE.weaponlnkd,
      wthrow = PX_POSTURE.wthrow, wthrowu = PX_POSTURE.wthrowu, wthrowd = PX_POSTURE.wthrowd,
      weaponfire = "sprites/sniper_rifle/fire", weaponfireu = "sprites/sniper_rifle/fireu",
      weaponfired = "sprites/sniper_rifle/fired",
    },
    sprites = {
      "sprites/px_hold/sniper_rifle", "sprites/sniper_rifle/laser", "sprites/sniper_rifle/flash",
    },
    sounds = { "sounds/sniper_firing.wav" },
    params = { gpu_prefix = "sprites/" },
  },
  { -- Burst Rifle: the worm aiming it, taking it out and firing it.
    weapon = "minigun",
    panel_icon = "sprites/burst_rifle/ico_burstr.png",
    worm_sprites = {
      weaponlnk = "sprites/burst_rifle/aim",
      weaponlnku = "sprites/burst_rifle/aimu",
      weaponlnkd = "sprites/burst_rifle/aimd",
      wthrow = "sprites/burst_rifle/draw",
      wthrowu = "sprites/burst_rifle/drawu",
      wthrowd = "sprites/burst_rifle/drawd",
      weaponfire = "sprites/burst_rifle/fire",
      weaponfireu = "sprites/burst_rifle/fireu",
      weaponfired = "sprites/burst_rifle/fired",
    },
  },
}

-- WEP_PATCH begin
-- Display names + named patches from each former weps/<slot>.wep,
-- as copy_from + name + patch (web editor style). Generated by tools/embed_weps.py.
local WEP_NAME = {
  air_strike = "Mortar Strike",
  aqua_sheep = "Ghost Sheep",
  banana_bomb = "Super Gravedigger",
  battle_axe = "Thumper Nade",
  bazooka = "Double Bazooka",
  blow_torch = "BlowTorch",
  bungee = "Hot Air Balloon",
  carpet_bomb = "Thumper Nade Strike",
  cluster_bomb = "Windy Cluster",
  crate_shower = "Crate Shower",
  crate_spy = "Crate Spy",
  damage_x2 = "Skunk",
  double_turn_time = "Mole Bomb",
  dynamite = "Dynamite",
  fast_walk = "Fast Walk",
  fire_punch = "Fire Jump",
  flame_thrower = "Flame Thrower",
  girder = "Baseball Bat",
  girder_pack = "3 Girder Pack",
  grenade = "Sticky Bomb",
  handgun = "Sniper Rifle",
  holy_grenade = "Hellish Hand-Grenade",
  homing_missile = "Igniter",
  homing_pigeon = "Blaster Worm",
  invisibility = "Teleport",
  jet_pack = "Helicopter",
  laser_sight = "Swim Suit",
  longbow = "Shadow-Bolt",
  low_gravity = "Gravity Control",
  mad_cow = "Cow Launcher",
  magic_bullet = "Cluster Bomb",
  mail_strike = "Pigeon Strike",
  mb_bomb = "Banana Express",
  mine = "Nuke Rocket",
  ming_vase = "Priceless Ming Vase",
  minigun = "Burst Rifle",
  mole_bomb = "Gravler",
  mole_squadron = "Gravler Strike",
  mortar = "S.M.A.R.T Bomb",
  ninja_rope = "Jump",
  old_woman = "Old Woman Launcher",
  parachute = "Hang-Glider",
  pneumatic_drill = "Super Drill",
  sheep = "Pogo Sheep",
  sheep_launcher = "Burning Sheep Launcher",
  shotgun = "Real Shotgun",
  skunk = "Remote Roller",
  super_banana = "Chilli Bomb",
  surrender = "Wind Changer",
}
local WEP_PATCH = {
  air_strike = {
    uses_turn = 0,
    k_count = 4,
    k_spacing = 30,
    collision_radius = 4331582,
    damage = 100,
    flight_flags = 466,
    gravity_pct = 260,
    fuse = 10000,
    detonation = 1,
    cluster_count = 5,
    cluster_speed = 30,
    cluster_power = 30,
    cluster_angle = -1,
    cluster_spread = 40,
    c_collision_radius = 4331646,
    c_damage = 100,
    c_blast = 15,
    c_impact = 2,
    c_flags = 260,
    c_gravity_pct = 160,
    c_wind_pct = 50,
    c_bounce_pct = 100,
    c_friction_pct = 100,
    c_fuse = 10000,
    c_missile_type = 2,
    c_render_size = 4194368,
    c_homing_strength = 50,
  },
  aqua_sheep = {
    requires_aiming = 0,
    uses_turn = 0,
    retreat = 5000,
    m_blast = 90,
    wind_pct = 50,
    fuse_default = 8000,
    fuse = 8000,
    render_size = 137342,
  },
  banana_bomb = {
    requires_aiming = 0,
    uses_turn = 0,
    pellets = 3,
    collision_radius = 4339766,
    bias = 75,
    blast = 50,
    impact = 5,
    flight_flags = 0,
    gravity_pct = 145,
    friction_pct = 116,
    fuse_default = 0,
    missile_type = 0,
    render_size = 4325376,
    homing_strength = 99,
    homing_arm = 50,
    cluster_speed = 37,
    cluster_power = 35,
    cluster_spread = 45,
    c_collision_radius = 4194304,
    c_bias = 50,
    c_blast = 18,
    c_impact = 5,
    c_flags = 0,
    c_gravity_pct = 0,
    c_wind_pct = 0,
    c_friction_pct = 116,
    c_fuse = 0,
    c_homing_strength = 99,
    c_homing_arm = 15,
    power_pct = 50,
    weight2 = 0,
  },
  battle_axe = {
    requires_aiming = 0,
    uses_turn = 0,
    fire_type = 1,
    subtype_param = 2,
    fire_method = 3,
    pellets = 2,
    grenade_style = 1,
    collision_radius = 4194304,
    bias = 10,
    damage = 100,
    blast = 40,
    impact = 1,
    flight_flags = 251,
    gravity_pct = 150,
    wind_pct = 50,
    bounce_pct = 100,
    friction_pct = 120,
    fuse = 9000,
    missile_type = 2,
    render_size = 4373598,
    homing_strength = 50,
    homing_turn = 8,
    detonation = 1,
    cluster_count = 6,
    cluster_speed = 40,
    cluster_power = 30,
    cluster_spread = 45,
    c_collision_radius = 4395070,
    c_damage = 100,
    c_blast = 30,
    c_impact = 5,
    c_flags = 252,
    c_gravity_pct = 120,
    c_bounce_pct = 100,
    c_friction_pct = 100,
    c_fuse = 9000,
    c_missile_type = 2,
    c_render_size = 4200512,
    c_homing_strength = 100,
    weight2 = 70,
  },
  bazooka = {
    requires_aiming = 0,
    uses_turn = 0,
    blast = 20,
  },
  blow_torch = {
    uses_turn = 0,
  },
  bungee = {
    retreat = -1,
    subtype_param = 12,
    fire_method = 100,
  },
  carpet_bomb = {
    uses_turn = 0,
    retreat = 3000,
    k_count = 3,
    k_spacing = 30,
    blast = 40,
    impact = 1,
    flight_flags = 251,
    gravity_pct = 150,
    render_size = 4439166,
    homing_strength = 50,
    homing_accel = 0,
    homing_kind = 0,
    detonation = 1,
    cluster_count = 6,
    cluster_speed = 40,
    cluster_power = 30,
    cluster_spread = 45,
    c_collision_radius = 137342,
    c_damage = 100,
    c_blast = 25,
    c_impact = 5,
    c_flags = 252,
    c_gravity_pct = 120,
    c_bounce_pct = 100,
    c_friction_pct = 100,
    c_fuse = 9000,
    c_missile_type = 2,
    power_pct = 50,
  },
  cluster_bomb = {
    requires_aiming = 0,
    uses_turn = 0,
    grenade_style = 0,
    bounce_extra = 48,
    cluster_count = 8,
    cluster_speed = 35,
    cluster_power = 25,
    cluster_spread = 40,
    c_flags = 615,
    c_gravity_pct = 200,
  },
  damage_x2 = {
    requires_aiming = 1,
    shots = 0,
    uses_turn = 1,
    creates_projectile = 1,
    fire_type = 2,
    subtype_param = 0,
    fire_method = 2,
    m_proximity = 2,
    m_fuse = 5,
    m_damage = 100,
    impact = 6,
    flight_flags = 131,
    gravity_pct = 100,
    wind_pct = 50,
    bounce_pct = 100,
    friction_pct = 100,
    missile_type = 3,
    render_size = 4331646,
    homing_strength = 100,
    homing_kind = 15,
    homing_arm = 120,
    homing_time = 43,
    detonation = 1,
    cluster_count = 1,
    c_damage = 100,
    c_blast = 30,
    c_impact = 6,
    c_flags = 131,
    c_gravity_pct = 100,
    c_wind_pct = 50,
    c_bounce_pct = 100,
    c_friction_pct = 100,
    c_fuse_default = 5000,
    c_fuse = 10000,
    c_missile_type = 3,
    c_render_size = 4331646,
    c_homing_strength = 100,
    c_homing_kind = 15,
    c_homing_arm = 120,
    c_homing_time = 43,
  },
  double_turn_time = {
    requires_aiming = 1,
    shots = 0,
    uses_turn = 1,
    creates_projectile = 1,
    fire_type = 2,
    subtype_param = 0,
    fire_method = 2,
    m_proximity = 2,
    m_fuse = 5,
    m_damage = 100,
    impact = 6,
    flight_flags = 131,
    gravity_pct = 100,
    wind_pct = 50,
    bounce_pct = 100,
    friction_pct = 100,
    fuse_default = 5000,
    fuse = 5000,
    space_control = 1,
    missile_type = 3,
    render_size = 4331646,
    homing_strength = 50,
    homing_kind = 15,
    homing_arm = 75,
    homing_time = 40,
    detonation = 1,
    cluster_count = 1,
    c_collision_radius = 137340,
    c_damage = 110,
    c_blast = 40,
    c_impact = 6,
    c_flags = 80,
    c_gravity_pct = 50,
    c_wind_pct = 50,
    c_bounce_pct = 100,
    c_friction_pct = 100,
    c_fuse_default = 5000,
    c_fuse = 20000,
    c_space_control = 1,
    c_missile_type = 4,
    c_render_size = 50,
    c_homing_strength = 65574,
    c_homing_turn = 159,
    c_homing_accel = 160,
    c_homing_speed = 160,
  },
  dynamite = {
    requires_aiming = 0,
    uses_turn = 0,
    retreat = 0,
  },
  fire_punch = {
    requires_aiming = 0,
    uses_turn = 0,
    fire_method = 45,
    spread = 80,
    power_pct = 2090598400,
  },
  girder = {
    uses_turn = 0,
    creates_projectile = 1,
    subtype_param = 2,
    fire_method = 30,
    pellets = 125,
  },
  girder_pack = {
    shots = 3,
    uses_turn = 0,
  },
  grenade = {
    requires_aiming = 0,
    uses_turn = 0,
    collision_radius = 4394622,
    bias = 0,
    damage = 0,
    blast = 0,
    fuse_default = 0,
    fuse = 2000000,
    missile_type = 0,
    homing_strength = 6,
    homing_kind = 2,
    homing_arm = 1,
    homing_time = 20000,
    detonation = 1,
    cluster_count = 1,
    c_collision_radius = 4194304,
    c_damage = 60,
    c_blast = 55,
    c_impact = 1,
    c_flags = 80,
    c_gravity_pct = 50,
    c_wind_pct = 50,
    c_friction_pct = 100,
    c_fuse_default = 4000,
    c_fuse = 4000,
    c_missile_type = 4,
    c_homing_turn = 467,
    c_homing_accel = 467,
    c_homing_speed = 467,
    power_pct = 25,
  },
  handgun = {
    requires_aiming = 0,
    shots = 3,
    uses_turn = 0,
    h_shots = 1,
    h_spread = 1000,
    h_delay = 0,
    h_range = 4398206,
    h_damage = 18,
    h_kind = 7,
    weight2 = 20,
  },
  holy_grenade = {
    requires_aiming = 0,
    uses_turn = 0,
    damage = 70,
    blast = 80,
    flight_flags = 8,
    detonation = 2,
    cluster_count = 150,
    cluster_speed = 70,
    cluster_power = 1000,
    cluster_angle = 1,
  },
  homing_missile = {
    uses_turn = 0,
    subtype_param = 3,
    bias = 0,
    impact = 2,
    gravity_pct = 0,
    fuse = 9000,
    missile_type = 2,
    render_size = 4194304,
    homing_strength = 0,
    homing_turn = 8,
    homing_accel = 0,
    homing_speed = 0,
    homing_kind = 0,
    homing_arm = 0,
    homing_time = 0,
    detonation = 2,
    cluster_count = 150,
    cluster_speed = 150,
    cluster_power = 1000,
    cluster_angle = 1,
  },
  homing_pigeon = {
    uses_turn = 0,
    subtype_param = 3,
    spread = 0,
    bias = 0,
    blast = 50,
    impact = 2,
    gravity_pct = 0,
    wind_pct = 0,
    fuse = 9000,
    missile_type = 0,
    render_size = 4194304,
    homing_strength = 0,
    homing_turn = 8,
    homing_accel = 0,
    homing_speed = 0,
    homing_kind = 0,
    homing_arm = 0,
    homing_time = 0,
    detonation = 1,
    cluster_count = 1,
    cluster_speed = 80,
    cluster_power = 80,
    cluster_spread = 100,
    c_impact = 1,
    c_flags = 249,
    c_gravity_pct = 125,
    c_bounce_pct = 99,
    c_friction_pct = 100,
    c_fuse = 7000,
    c_missile_type = 2,
    c_render_size = 4398206,
    c_homing_strength = 60,
  },
  invisibility = {
    requires_aiming = 0,
    uses_turn = 1,
    subtype_param = 10,
    pellets = 0,
  },
  jet_pack = {
    retreat = -1,
    fire_method = 255,
    pellets = 8,
  },
  laser_sight = {
    requires_aiming = 0,
  },
  longbow = {
    requires_aiming = 0,
    uses_turn = 0,
    subtype_param = 2,
    fire_method = 3,
    pellets = 3,
    collision_radius = 4332604,
    bias = 8,
    damage = 250,
    blast = 28,
    impact = 2,
    flight_flags = 453,
    gravity_pct = 180,
    wind_pct = 50,
    bounce_pct = 100,
    friction_pct = 110,
    fuse = 10000,
    missile_type = 2,
    render_size = 1077936192,
    homing_strength = 80,
  },
  low_gravity = {
    retreat = -1,
    pellets = 8,
  },
  mad_cow = {
    requires_aiming = 0,
    uses_turn = 0,
    fire_type = 1,
    subtype_param = 3,
    fire_method = 3,
    spread = 50,
  },
  magic_bullet = {
    requires_aiming = 1,
    subtype_param = 2,
    spread = 0,
    grenade_style = 1,
    collision_radius = 0,
    damage = 0,
    blast = 20,
    flight_flags = 131,
    fuse_default = 5000,
    fuse = 0,
    missile_type = 2,
    render_size = 4331614,
    homing_strength = 100,
    homing_turn = 8,
    homing_accel = 0,
    homing_speed = 0,
    homing_kind = 0,
    homing_arm = 0,
    homing_time = 0,
    detonation = 1,
    cluster_count = 5,
    cluster_speed = 30,
    cluster_power = 30,
    cluster_spread = 45,
    c_collision_radius = 137342,
    c_damage = 100,
    c_blast = 20,
    c_impact = 1,
    c_flags = 131,
    c_gravity_pct = 100,
    c_wind_pct = 50,
    c_bounce_pct = 100,
    c_friction_pct = 100,
    c_fuse = 9000,
    c_missile_type = 2,
    c_render_size = 4331614,
    c_homing_strength = 100,
    c_homing_turn = 8,
    power_pct = 25,
    weight2 = 70,
  },
  mail_strike = {
    uses_turn = 0,
    retreat = 3000,
    subtype_param = 0,
    k_count = 3,
    k_spacing = 45,
    h_delay = 1200,
    collision_radius = 4331646,
    blast = 55,
    impact = 3,
    flight_flags = 0,
    bounce_pct = 95,
    fuse = 12000,
    missile_type = 1,
    homing_strength = 1,
    homing_turn = 25,
    homing_accel = 40,
    homing_speed = 50,
    homing_kind = 1,
    detonation = 1,
    cluster_count = 18,
    cluster_speed = 15,
    cluster_power = 30,
    cluster_spread = 20,
    c_collision_radius = 137282,
    c_impact = 1,
    c_wind_pct = 50,
    c_bounce_pct = 99,
    c_friction_pct = 45,
    c_fuse = 10000,
    c_missile_type = 2,
    c_render_size = 137282,
    c_homing_strength = 20,
    c_homing_turn = 8,
    power_pct = 50,
  },
  mb_bomb = {
    requires_aiming = 0,
    uses_turn = 0,
    retreat = 3000,
    subtype_param = 0,
    k_spacing = 30,
    h_delay = 150,
    h_flag = 52,
    collision_radius = 0,
    damage = 80,
    blast = 70,
    impact = 1,
    flight_flags = 131,
    gravity_pct = 100,
    wind_pct = 50,
    bounce_pct = 100,
    fuse_default = 3000,
    fuse = 10000,
    render_size = 4398718,
    homing_strength = 100,
    detonation = 1,
    cluster_count = 5,
    cluster_speed = 45,
    cluster_power = 30,
    cluster_spread = 25,
    c_collision_radius = 4331646,
    c_damage = 80,
    c_blast = 60,
    c_impact = 1,
    c_flags = 131,
    c_gravity_pct = 100,
    c_wind_pct = 50,
    c_bounce_pct = 100,
    c_friction_pct = 100,
    c_fuse = 9000,
    c_missile_type = 2,
    c_render_size = 204414,
    c_homing_strength = 100,
    c_homing_turn = 8,
    power_pct = 50,
  },
  mine = {
    requires_aiming = 0,
    uses_turn = 0,
    fire_method = 2,
    m_proximity = 2,
    m_fuse = 5,
    m_mask = 1,
    m_trigger = 0,
    m_damage = 70,
    m_blast = 0,
    impact = 2,
    flight_flags = 131,
    gravity_pct = 100,
    wind_pct = 50,
    bounce_pct = 100,
    friction_pct = 100,
    fuse = 3000,
    missile_type = 2,
    render_size = 4331614,
    homing_turn = 8,
    cluster_count = 5,
    cluster_speed = 33,
    cluster_power = 33,
    cluster_spread = 30,
    c_collision_radius = 4332670,
    c_damage = 25,
    c_blast = 20,
    c_impact = 1,
    c_flags = 131,
    c_gravity_pct = 100,
    c_wind_pct = 50,
    c_bounce_pct = 100,
    c_friction_pct = 100,
    c_fuse = 7770,
    c_missile_type = 2,
    c_homing_turn = 8,
    weight2 = 100,
  },
  ming_vase = {
    requires_aiming = 0,
    uses_turn = 0,
  },
  minigun = {
    requires_aiming = 0,
    uses_turn = 0,
    h_shots = 10,
    h_spread = 63,
    h_delay = 6,
    h_flag = 2,
    bias = 6,
    h_radius = 15,
    h_damage = 7,
  },
  mole_bomb = {
    requires_aiming = 0,
    uses_turn = 0,
    retreat = 3000,
    fire_type = 1,
    subtype_param = 3,
    fire_method = 3,
    spread = 0,
    collision_radius = 137340,
    damage = 110,
    blast = 40,
    impact = 2,
    flight_flags = 0,
    gravity_pct = 0,
    friction_pct = 85,
    fuse = 20000,
    space_control = 0,
    missile_type = 4,
    render_size = 50,
    homing_strength = 65574,
    homing_turn = 246,
    homing_accel = 247,
    homing_speed = 248,
    detonation = 0,
    weight2 = 100,
  },
  mole_squadron = {
    uses_turn = 0,
    k_count = 4,
    k_spacing = 15,
    h_delay = 110,
    collision_radius = 135228,
    blast = 37,
    impact = 2,
    flight_flags = 0,
    gravity_pct = 0,
    fuse_default = 3000,
    fuse = 5000,
    homing_turn = 246,
    homing_accel = 247,
    homing_speed = 248,
  },
  mortar = {
    requires_aiming = 0,
    uses_turn = 0,
    subtype_param = 3,
    spread = 0,
    collision_radius = 170110,
    flight_flags = 250,
    gravity_pct = 120,
    friction_pct = 125,
    cluster_count = 7,
    cluster_speed = 50,
    cluster_angle = 0,
    cluster_spread = 45,
    c_damage = 115,
    c_blast = 25,
    c_impact = 1,
    c_flags = 0,
    c_gravity_pct = 600,
    c_wind_pct = 0,
    c_missile_type = 1,
    c_homing_strength = 1,
    c_homing_turn = 6,
    c_homing_accel = 500,
    c_homing_kind = 1,
    c_homing_arm = 1100,
    c_homing_time = 1200,
  },
  ninja_rope = {
    requires_aiming = 0,
    retreat = 3000,
    creates_projectile = 1,
    fire_type = 1,
    subtype_param = 2,
    fire_method = 3,
    pellets = 2,
    grenade_style = 1,
    bias = 10,
    damage = 100,
    blast = 50,
    impact = 1,
    flight_flags = 131,
    gravity_pct = 100,
    wind_pct = 50,
    bounce_pct = 100,
    friction_pct = 100,
    fuse_default = 5000,
    missile_type = 2,
    render_size = 4331614,
    homing_strength = 100,
    homing_turn = 8,
    weight2 = 70,
  },
  old_woman = {
    requires_aiming = 0,
    uses_turn = 0,
    fire_type = 1,
    subtype_param = 3,
    fire_method = 3,
    spread = 50,
    flight_flags = 135,
    fuse = 6000,
    homing_time = 65,
    cluster_count = 20,
    cluster_speed = 30,
    cluster_power = 2000,
  },
  pneumatic_drill = {
    requires_aiming = 0,
    uses_turn = 0,
    grenade_style = 2000,
  },
  sheep = {
    requires_aiming = 0,
    uses_turn = 0,
    m_fuse = 6,
    m_blast = 65,
    impact = 2,
    friction_pct = 70,
    fuse_default = 0,
    missile_type = 2,
    render_size = 1078074494,
    detonation = 1,
    cluster_count = 48,
    cluster_speed = 1,
    cluster_power = 30,
    cluster_spread = 45,
    c_flags = 249,
    c_gravity_pct = 20,
    c_wind_pct = 50,
    c_bounce_pct = 65,
    c_friction_pct = 75,
    c_fuse = 2000,
    c_missile_type = 2,
    c_render_size = 2,
    c_homing_strength = 10,
  },
  sheep_launcher = {
    requires_aiming = 0,
    uses_turn = 0,
    subtype_param = 3,
    spread = 0,
    collision_radius = 0,
    damage = 100,
    blast = 50,
    impact = 1,
    gravity_pct = 50,
    wind_pct = 0,
    fuse = 9000,
    space_control = 0,
    render_size = 4194430,
    homing_strength = 30,
    homing_accel = 50,
    homing_kind = 100,
    homing_arm = 50,
    detonation = 2,
    cluster_count = 40,
    cluster_speed = 100,
    cluster_power = 4000,
  },
  shotgun = {
    requires_aiming = 0,
    uses_turn = 0,
    h_delay = 10,
    bias = 10,
    h_range = 4365438,
  },
  skunk = {
    requires_aiming = 0,
    uses_turn = 0,
    m_fuse = 15,
    m_mask = 1,
    bias = 10,
    m_damage = 110,
    m_blast = 43,
    flight_flags = 80,
    gravity_pct = 30,
    bounce_pct = 101,
    friction_pct = 90,
    fuse_default = 0,
    fuse = 15000,
    render_size = 1078139998,
    homing_strength = 110,
    homing_turn = 25,
    homing_accel = 50,
    homing_speed = 88,
    homing_kind = 0,
    homing_arm = 0,
    homing_time = 88,
    detonation = 0,
    cluster_count = 0,
    c_damage = 0,
    c_blast = 0,
    c_impact = 0,
    c_flags = 0,
    c_gravity_pct = 0,
    c_wind_pct = 0,
    c_bounce_pct = 0,
    c_friction_pct = 0,
    c_fuse_default = 0,
    c_fuse = 0,
    c_space_control = 0,
    c_missile_type = 0,
    c_render_size = 0,
    c_homing_strength = 0,
    c_homing_kind = 0,
    c_homing_arm = 0,
    c_homing_time = 0,
    weight2 = 70,
  },
  super_banana = {
    requires_aiming = 0,
    uses_turn = 0,
    retreat = 3000,
    grenade_style = 1,
    damage = 75,
    blast = 50,
    fuse_default = 5000,
    fuse = 0,
    space_control = 0,
    render_size = 4331614,
    detonation = 0,
    cluster_count = 20,
    cluster_speed = 30,
    cluster_power = 1500,
    cluster_spread = 45,
    c_collision_radius = 137342,
    c_bias = 1,
    c_blast = 20,
    c_fuse = 2000,
    c_space_control = 0,
    c_render_size = 4331614,
    power_pct = 25,
    weight2 = 70,
  },
  surrender = {
    requires_aiming = 0,
    uses_turn = 0,
    retreat = 0,
    subtype_param = 19,
    pellets = 8,
  },
}
-- WEP_PATCH end

for _, list in ipairs({ PORTED, PX_ART }) do
  for _, w in ipairs(list) do
    -- copy_from + name + named patch (stock base); was weps/<slot>.wep
    local spec = { copy_from = w.weapon, name = WEP_NAME[w.weapon] }
    if WEP_PATCH[w.weapon] then
      spec.patch = WEP_PATCH[w.weapon]
    end
    for key, value in pairs(w) do
      spec[key] = value
    end
    wa.weapons.replace(spec)
  end
end

-- The two with a script of their own. Both run from worm messages, which WA
-- sends in lockstep on every peer and in replays.

-- Super Drill (PX weapon_super_drill): WA keeps drilling as it always does,
-- and a hidden actor cuts a second hole at the worm each frame until WA's
-- drill stops. The same as the super_drill example.
local drills = {}

local function follow_drill(worm, id)
  local started, waiting = false, 0
  return function(a)
    if worm.drilling then
      started = true
      wa.land.cut({ x = worm.x, y = worm.y, shape = "drill" })
      return
    end
    -- WA enters its drilling state a few frames after the shot.
    if not started and waiting < 4 then
      waiting = waiting + 1
      return
    end
    drills[id] = nil
    a:despawn()
  end
end

-- Fire Jump (PX Fire_Jump_script): WA's fire punch, whose speed then follows
-- PX's timeline, counted in frames from the punch -- up at once, forward
-- after half a second, a little higher at one second, and from 80 frames a
-- fall cut back to 4 pixels a frame whenever it passes 5, until 210. PX
-- speeds are pixels per frame; WA's are 16.16. See
-- docs/px-reverse-engineering.md.
--
-- PX counts from FireFinal, which WA calls only once the punch's wind-up has
-- played, not when fire is pressed. FireFinal starts the punch at -6 pixels
-- a frame; the worm stood still until then. So the count starts on the
-- first frame after fire is pressed that the worm is rising.
--
-- WA keeps the worm in its punch state until it has stopped, so the punch
-- itself cuts the way up and burns worms on it, all jump long: PX adds no cut.
local PX = 0x10000
local jumps = {}   -- worm id -> frames since the punch
local winding = {} -- worm id -> frames since fire was pressed
-- A wind-up never takes this long; give up rather than fire late.
local WIND_UP_MAX = 100

local function fire_jump(worm, t)
  if t == 1 then
    worm.vy = -9 * PX
  elseif t == 30 then
    worm.vx = worm.facing * 4 * PX
  elseif t == 60 then
    worm.vy = worm.vy - PX
  end
  if t > 80 and t < 210 and worm.vy > 5 * PX then
    worm.vy = 4 * PX
  end
end

wa.on.worm_message(function(worm, msg)
  if msg == wa.msg.FIRE_WEAPON then
    if worm.weapon == "pneumatic_drill" and not drills[worm.id]
        and worm:ammo("pneumatic_drill") ~= 0 then
      local id = worm.id
      drills[id] = wa.actors.spawn({
        sprite = false, x = worm.x, y = worm.y,
        gravity = false, collide = false, owner = worm,
        on = follow_drill(worm, id),
      })
    elseif worm.weapon == "fire_punch" and worm:ammo("fire_punch") ~= 0 then
      winding[worm.id] = 0
    elseif worm.weapon == "handgun" and worm:ammo("handgun") ~= 0 then
      -- The Sniper Rifle's own shot, over WA's (PX's snipfiring).
      wa.sound.play(worm, "sounds/sniper_firing.wav")
    end
    -- Neither eats the shot: WA's drill and fire punch still run.
    return
  end
  if msg == wa.msg.FRAME_FINISH and winding[worm.id] then
    if worm.vy < 0 then
      winding[worm.id], jumps[worm.id] = nil, 0
    else
      local w = winding[worm.id] + 1
      winding[worm.id] = w < WIND_UP_MAX and w or nil
    end
  end
  if msg == wa.msg.FRAME_FINISH and jumps[worm.id] then
    local t = jumps[worm.id] + 1
    fire_jump(worm, t)
    jumps[worm.id] = t < 211 and t or nil
  end
end)

-- ------------------------------------------ PX's sprite builder, at run time
--
-- PX draws many weapons' holds at run time (p_sprite_builder, WormSprite).
-- Over a worm posture with no weapon in it -- def_shot_aim_*, the sheets
-- below -- it draws the weapon and a hand, each placed and turned from the
-- aim angle by the weapon's CWormAnimParams, and grows the weapon in over the
-- first 20 frames of aiming. This does the same with two actors per aiming
-- worm, from worm messages, so in lockstep.
--
-- It reads worm.aim (the aim WA draws, 0 straight down .. 1 straight up:
-- PX's FireAngle) and worm.aiming (WA draws the worm with its weapon out:
-- PX's WS_AIMING or WS_SETPOWER). On an engine without them it does
-- nothing.

-- In front of worms and terrain, as the sentry's gun.
local HOLD_DEPTH = 0x10000

-- WormSprite's grow-in, counter 0..20: to 2.7 * c/20 up to 9, then 0.025
-- smaller a frame, then 0.9, 0.95, and full size from 20.
local PICK = {}
do
  local s = 0
  for c = 0, 20 do
    if c >= 20 then s = 1
    elseif c > 17 then s = c / 20
    elseif c > 9 then s = s - 0.025
    else s = 2.7 * c / 20 end
    PICK[c] = s
  end
end

-- Slot -> the weapon's CWormAnimParams, as its PX script states them.
local PX_HOLDS = {
  grenade = { -- Sticky Bomb (sb_script)
    -- Thrown: once fired it has left the worm's hands, and WA puts nothing
    -- away (as for its own grenades), so neither does the rule.
    thrown = true,
    sheet = "sprites/px_hold/sticky_bomb", hand_type = 1, hand_radius = 24,
    hand_rotation = 1.0, hand_radial_rotation = 1.05, hand_scale = 0.8,
    weap_rotation = 0.5, weap_radial_rotation = 0.9, weap_radius = 10,
  },
  super_banana = { -- Chilli Bomb (chilli_bomb_anim)
    thrown = true,
    sheet = "sprites/px_hold/chilli_bomb", hand_type = 1, hand_radius = 13,
    hand_scale = 0.8, weap_rotation = 0.5, weap_radius = 9,
  },
  homing_missile = { -- Igniter (igniter_anim)
    -- Up through the shot too: it has no firing poses of its own, so WA
    -- fires it in the aim posture, empty-handed without the hold. Not PX's.
    keep_while_firing = true,
    sheet = "sprites/px_hold/igniter", hand_type = 2, hand_radius = -6.0,
    hand_rotation = 1.0, hand_radial_rotation = 0.9, hand_scale = 0.8,
    weap_rotation = 1.0, weap_radial_rotation = 0.0, weap_radius = 0.0,
  },
  mine = { -- Nuke Rocket (nuke_rocket_anim): held at a fixed angle, not
    -- the aim's (dont_rotate_with_angle), and placed, so never put away.
    thrown = true,
    sheet = "sprites/px_hold/nuke_rocket", hand_type = 2, hand_radius = 13.0,
    hand_rotation = -0.6, hand_radial_rotation = -0.95, hand_scale = 1.0,
    weap_rotation = 0.45, weap_radial_rotation = 1.0, weap_radius = 8.5,
    static = { weap = -0.1, hand = 0.4 }, -- ang_if_static, hand_ang_if_static
  },
  handgun = { -- Sniper Rifle (sniper_rifle_script): its hand at scale 0
    -- Up through each shot, with its laser, over the snipefire poses (the
    -- worm lit by the muzzle), so it does not flicker between the three.
    -- Not PX's: PX hides it until the worm aims again.
    keep_while_firing = true,
    -- A muzzle flash on each shot. Not PX's: its rifle and snipefire poses
    -- have none. The sentry gun's flare, smaller, at the barrel's tip (30
    -- pixels out, on the barrel 2 to the side, as the laser leaves it).
    flash = { sheet = "sprites/sniper_rifle/flash", out = 30, side = 2, scale = 0.45, frames = 3 },
    sheet = "sprites/px_hold/sniper_rifle", draw_hand = false, hand_radius = -6.0,
    hand_rotation = 1.0, hand_radial_rotation = 0.9,
    weap_rotation = 1.0, weap_radial_rotation = 0.0, weap_radius = 0.1,
  },
  longbow = { -- Shadow-Bolt (shadow_bolt_script): no hand, the bolt animated
    -- The crossbow stays up through the shot: it has no firing poses of
    -- its own, so WA fires it in the aim posture. Not PX's.
    keep_while_firing = true,
    sheet = "sprites/px_hold/shadow_bolt", draw_hand = false, hand_radius = 0.0,
    hand_rotation = 0.0, hand_radial_rotation = 0.0,
    weap_rotation = 1.0, weap_radial_rotation = 0.0, weap_radius = 3.5,
    animate = true, anim_speed = 1.30, frames = 6,
  },
}

-- CWormAnimParams' own defaults, for whatever a weapon's script leaves out:
-- the Chilli Bomb sets neither radial rotation, so its hold is cocked back
-- behind the worm's head (1.0: half a turn) as a throw.
local PX_HOLD_DEFAULTS = {
  hand_radius = 1.0, hand_rotation = 1.0, hand_radial_rotation = 1.0,
  hand_scale = 1.0, hand_type = 2, weap_rotation = 1.0,
  weap_radial_rotation = 1.0, weap_radius = 1.0, anim_speed = 1.0,
}
for _, p in pairs(PX_HOLDS) do
  for k, v in pairs(PX_HOLD_DEFAULTS) do
    if p[k] == nil then
      p[k] = v
    end
  end
end

-- WormSprite::CalculateFrame and WeapSprite::CalculateFrame: a phase from 0
-- to 1 through the sheet, anim_speed * 0.03 a frame, back to 0 past 0.99.
local function next_phase(phase, anim_speed)
  if phase > 0.99 then
    return 0
  end
  return phase + anim_speed * 30 / 1000
end

local function frame_of(phase, frames)
  return math.min(math.floor(phase * frames), frames - 1)
end

local held = {} -- worm id -> { slot, weapon, hand, counter, phase, aim }

local function drop_hold(id)
  local h = held[id]
  if h then
    h.weapon:despawn()
    if h.hand then
      h.hand:despawn()
    end
    if h.flash then
      h.flash:despawn()
    end
    held[id] = nil
  end
end

-- One sprite of the hold: centred at (dx, dy) pixels from the worm, turned
-- by `angle` radians, as PX computes them for a worm facing right; facing
-- left mirrors all three, as PX's left-facing formulas do.
local function place(a, worm, dx, dy, angle, scale, look)
  local f = worm.facing
  -- Positions are 16.16 integers.
  a.x = worm.x + math.floor(f * dx * 0x10000 + 0.5)
  a.y = worm.y + math.floor(dy * 0x10000 + 0.5)
  a.vx, a.vy = 0, 0
  a.facing = f
  local g = { angle = math.deg(angle * f) % 360, scale = scale, depth = HOLD_DEPTH }
  for k, v in pairs(look or {}) do
    g[k] = v
  end
  a:gfx(g)
end

-- worm.aim, or nil on an engine without it: a worm has no such field there,
-- and reading one is an error rather than nil.
local function aim_of(worm)
  local ok, aim = pcall(function() return worm.aim end)
  return ok and aim or nil
end

local function spawn_hold(worm, slot)
  local p = PX_HOLDS[slot]
  local function actor(sheet)
    return wa.actors.spawn({
      sprite = sheet, x = worm.x, y = worm.y, gravity = false,
      collide = false, owner = worm, on = function() end,
    })
  end
  local h = { slot = slot, counter = 0, phase = 0 }
  if p.flash then
    h.flash = actor(p.flash.sheet)
    h.flash:frame(0) -- its empty frame, until a shot
  end
  h.weapon = actor(p.sheet)
  -- A weapon PX draws with no hand: draw_hand = false.
  if p.draw_hand ~= false then
    h.hand = actor(PX_HANDS[p.hand_type])
  end
  held[worm.id] = h
  return h
end

-- WormSprite::CalculateAngle: the hold at its aim, grown to PICK[counter].
local function place_hold(worm, h)
  local p = PX_HOLDS[h.slot]
  -- dont_rotate_with_angle: placed as if aimed level, turned by fixed angles.
  local aim = p.static and 0.5 or h.aim
  local pi = math.pi
  local rot = (1 - aim) * pi
  local rot_w = rot + pi * p.weap_radial_rotation
  local rot_h = rot - pi * p.hand_radial_rotation
  local grow = PICK[h.counter]
  place(h.weapon, worm, math.sin(rot_w) * p.weap_radius, -math.cos(rot_w) * p.weap_radius,
    p.static and p.static.weap * pi or pi - pi * aim - pi * (1 - p.weap_rotation), grow)
  if p.animate then
    h.phase = next_phase(h.phase, p.anim_speed)
    h.weapon:frame(frame_of(h.phase, p.frames))
  end
  if h.hand then
    place(h.hand, worm, math.sin(rot_h) * p.hand_radius, -math.cos(rot_h) * p.hand_radius,
      p.static and p.static.hand * pi or rot + pi * p.hand_rotation, grow * p.hand_scale)
  end
  if h.flash then
    -- At the barrel's tip, pointing along the aim (the art points right).
    -- Additive and white, in front of the weapon, as the sentry's flare.
    local f = p.flash
    local lit = (h.flash_left or 0) > 0
    if lit then
      h.flash_left = h.flash_left - 1
    end
    h.flash:frame(lit and 1 or 0)
    place(h.flash, worm, math.sin(rot) * f.out - math.cos(rot) * f.side,
      -math.cos(rot) * f.out - math.sin(rot) * f.side, rot - pi / 2, f.scale,
      { tint = 0xFFFFFF, blend = "add", depth = HOLD_DEPTH - 0x100 })
  end
end

-- Putting a weapon away. Not PX's: PX drops the hold the frame the worm
-- stops aiming. WA puts a weapon away by playing the worm's draw sheet
-- backwards, standing, over 20 frames; after a gun's last shot it has
-- already selected the next weapon. So a hold last aimed (`put_away`
-- remembers it) comes back when the worm stands with another weapon, and
-- shrinks out along the grow-in played backwards, a step a frame.
local put_away = {} -- worm id -> { slot, aim } of the hold last aimed

local function update_put_away(worm)
  local h = held[worm.id]
  if h and h.putting_away then
    if worm.state ~= "standing" or h.counter == 0 then
      drop_hold(worm.id)
      return
    end
    h.counter = h.counter - 1
    place_hold(worm, h)
    return
  end
  local last = put_away[worm.id]
  local state = worm.state
  if last and worm.aiming then
    -- Aiming another weapon: this one was never put away here.
    put_away[worm.id] = nil
    return
  end
  if not last or state == nil then
    -- No name: WA's firing states between the last aim and the put-away.
    return
  end
  put_away[worm.id] = nil
  if state == "standing" and worm.weapon ~= last.slot then
    h = spawn_hold(worm, last.slot)
    h.aim, h.counter, h.putting_away = last.aim, 20, true
    place_hold(worm, h)
  end
end

local function update_hold(worm)
  local p = PX_HOLDS[worm.weapon]
  local aim = p and aim_of(worm)
  if not aim or not worm.aiming then
    local h = held[worm.id]
    -- Fired, in WA's firing states (no state name) with the weapon still
    -- selected. Walking is unnamed too, hence the fire key.
    if h and h.firing and PX_HOLDS[h.slot].keep_while_firing and worm.state == nil
        and worm.weapon == h.slot then
      local flash = PX_HOLDS[h.slot].flash
      if flash and not h.shot_out then
        -- The first frame of WA's firing states: the shot.
        h.flash_left = flash.frames
      end
      h.shot_out = true
      place_hold(worm, h)
      return
    end
    if h and not h.putting_away then
      if not (h.firing and PX_HOLDS[h.slot].thrown) then
        put_away[worm.id] = { slot = h.slot, aim = h.aim }
      end
      drop_hold(worm.id)
    end
    update_put_away(worm)
    return
  end
  put_away[worm.id] = nil
  local h = held[worm.id]
  if h and (h.slot ~= worm.weapon or h.putting_away) then
    drop_hold(worm.id)
    h = nil
  end
  h = h or spawn_hold(worm, worm.weapon)
  -- Kept for anything drawn with the hold (the Sniper Rifle's laser), so it
  -- turns with the weapon: worm.aim is WA's smoothed crosshair (+0x270),
  -- which WA also rewrites at render time, between sim frames.
  -- The wind-up after the fire key still counts as aiming; the shot is
  -- over only once the worm aims again after WA's firing states.
  if h.shot_out then
    h.firing, h.shot_out = false, false
  end
  h.aim = aim
  place_hold(worm, h)
  h.counter = math.min(h.counter + 1, 20)
end

wa.on.worm_message(function(worm, msg)
  if msg == wa.msg.FIRE_WEAPON and held[worm.id] then
    held[worm.id].firing = true
  end
  if msg == wa.msg.FRAME_FINISH then
    update_hold(worm)
  end
end)

-- ------------------------------------------ the Sniper Rifle's laser sight
--
-- PX's LaserSight (weapon_gun_sniper_rifle_sb, on utility_laser_pointer's
-- laserray): while the current worm aims the rifle, a red ray from 12 pixels
-- out along the aim to the first thing in its way, drawn every rendered
-- frame as 100-pixel quads of laser.png, added to the scene, narrowing along
-- the ray, with a faint 7-pixel tip. It is drawing only: wa.on.draw, never
-- the simulation.

local LASER_LEN = 15000
local LASER_WIDTH = 2
local LASER_STEP = 5 -- PX's Trace tests every 5 pixels
-- PX starts the ray on the worm's centre line, but the rifle art's barrel
-- runs 2 pixels to its left (columns 26-29 of 60), so the ray ran that far
-- under the barrel. It starts on the barrel instead.
local LASER_BARREL = 2
local function argb(a, r, g, b)
  return ((a * 256 + r) * 256 + g) * 256 + b
end
local LASER_RED, LASER_START, LASER_TIP =
  argb(255, 255, 48, 48), argb(192, 255, 96, 96), argb(16, 255, 48, 48)
-- PX's Trace stops at anything its 2x2 mask touches. Terrain is traced
-- exactly; objects by these radii in pixels, an estimate of their masks.
local STOPPERS = { { wa.worms, 6 }, { wa.mines, 4 }, { wa.crates, 10 }, { wa.oil, 9 } }

local function laser_length(x, y, dx, dy, shooter)
  local P = 0x10000
  local len = LASER_LEN
  local hit = wa.land.trace(math.floor(x), math.floor(y),
    math.floor(x + dx * LASER_LEN * P), math.floor(y + dy * LASER_LEN * P))
  if hit then
    len = math.sqrt(((hit.x - x) / P) ^ 2 + ((hit.y - y) / P) ^ 2)
  end
  for _, s in ipairs(STOPPERS) do
    local list, r = s[1], s[2]
    if list and list.all then
      for _, o in ipairs(list.all()) do
        if o.id ~= shooter then
          local ox, oy = (o.x - x) / P, (o.y - y) / P
          local t = ox * dx + oy * dy
          if t > 0 and t < len and math.abs(ox * dy - oy * dx) < r then
            len = t
          end
        end
      end
    end
  end
  return math.floor(len / LASER_STEP) * LASER_STEP
end

-- laserray's MakeLaserRayF, point for point.
local function laser_ray(x, y, ang, len)
  local P = 0x10000
  local rdx, rdy = math.sin(ang - 1.57), -math.cos(ang - 1.57)
  local dx, dy = math.sin(ang), -math.cos(ang)
  local tx, ty = x, y
  local nparts = math.floor(len / 100)
  local w = (wa.draw.random() / 4 + 0.85) * LASER_WIDTH / 2
  local wdx, wdy = w * rdx * P, w * rdy * P
  local wscale = 1
  local lastl = len - nparts * 100
  local colors
  for i = 0, nparts do
    local l = i == nparts and lastl or 100
    if l <= 0 then break end
    local p0, p3 = { tx + wdx, ty + wdy }, { tx - wdx, ty - wdy }
    w = wscale * (wa.draw.random() / 3 + 0.82) * LASER_WIDTH
    wdx, wdy = w * rdx * P, w * rdy * P
    wscale = wscale - 0.75 / (nparts + 1)
    local ex, ey = tx + dx * l * P, ty + dy * l * P
    colors = { LASER_RED, LASER_RED, LASER_RED, LASER_RED }
    if i == 0 then
      colors[1], colors[4] = LASER_START, LASER_START
    end
    wa.draw.quad({
      points = { p0, { ex + wdx, ey + wdy }, { ex - wdx, ey - wdy }, p3 },
      colors = colors, sprite = "sprites/sniper_rifle/laser", blend = "add",
    })
    tx, ty = ex, ey
  end
  local ex, ey = tx + dx * 7 * P, ty + dy * 7 * P
  wa.draw.quad({
    points = { { tx + wdx, ty + wdy }, { ex + wdx, ey + wdy }, { ex - wdx, ey - wdy }, { tx - wdx, ty - wdy } },
    colors = { LASER_RED, LASER_TIP, LASER_TIP, LASER_RED },
    sprite = "sprites/sniper_rifle/laser", blend = "add",
  })
end

if wa.on.draw then
  wa.on.draw(function()
    for _, worm in ipairs(wa.worms.all()) do
      -- The aim the rifle was drawn with, so the ray leaves along it; while
      -- the worm aims or fires the rifle, not while it puts it away.
      local h = worm.turn and held[worm.id]
      local aim = h and h.slot == "handgun" and not h.putting_away and h.aim
      if aim then
        local ang = (1 - aim) * 3.14159
        if worm.facing < 0 then
          ang = 6.28318 - ang
        end
        local P = 0x10000
        -- The art's left, turned with the aim and mirrored with the worm.
        local side = LASER_BARREL * worm.facing * P
        local x = worm.x + math.sin(ang) * 12 * P - math.cos(ang) * side
        local y = worm.y - math.cos(ang) * 12 * P - math.sin(ang) * side
        laser_ray(x, y, ang, laser_length(x, y, math.sin(ang), -math.cos(ang), worm.id))
      end
    end
  end)
end

-- ------------------------------------ PX's missile sprites, at run time
--
-- For some weapons PX draws the missile itself (p_sprite_builder,
-- WeapSprite) and leaves WA's sprite 0: a sprite that follows the missile,
-- turned to its flight, mirrored when it flies left, and, if `animate`,
-- stepped through its sheet as a hold is. Here it is a GPU actor per
-- missile, placed from wa.on.missile_frame after WA has moved the missile.
-- It reads m.weapon (the missile's slot); on an engine without it nothing
-- matches and nothing is drawn. With `hide`, WA draws nothing for the
-- missile (m.sprite = 0), as PX's sprite 0 does; its record keeps its
-- sprite, which a thrown weapon's worm posture is picked by.

-- Slot -> the weapon's WeapSpriteParams, as its PX script states them.
local PX_WEAP_SPRITES = {
  longbow = { -- Shadow-Bolt
    sheet = "sprites/shadow_bolt/bolt", animate = true, anim_speed = 1.30, frames = 6,
  },
  super_banana = { -- Chilli Bomb (chilli_bomb_anim) and the five it bursts into
    sheet = "sprites/px_hold/chilli_bomb", frames = 1,
    -- WA's own sprite 0, as PX's record has it: nothing under the chilli.
    hide = true,
  },
  homing_missile = { -- Igniter (igniter_anim: igniter_bullet, 16 frames)
    sheet = "sprites/igniter/flight", animate = true, anim_speed = 1.0, frames = 16,
  },
}

local flying = {} -- missile id -> { actor, phase, seen }

-- The actor goes when its missile stops reporting: WA has freed it.
local function follow_missile(id)
  return function(a)
    local f = flying[id]
    if f and f.seen then
      f.seen = false
      return
    end
    if f and f.actor == a then
      flying[id] = nil
    end
    a:despawn()
  end
end

-- The worm whose turn it is: WeapSprite's owner (GetCurrentWorm()). A
-- missile frame gives no spawn owner of its own.
local function current_worm()
  for _, w in ipairs(wa.worms.all()) do
    if w.turn then
      return w
    end
  end
end

wa.on.missile_frame(function(m)
  local p = PX_WEAP_SPRITES[m.weapon]
  if p and p.hide and m.phase == "pre" then
    m.sprite = 0
  end
  p = m.phase == "post" and p
  if not p then
    return
  end
  local f = flying[m.id]
  if not f then
    local owner = current_worm()
    if not owner then
      return
    end
    f = { phase = 0 }
    f.actor = wa.actors.spawn({
      sprite = p.sheet, x = m.x, y = m.y, gravity = false, collide = false,
      owner = owner, on = follow_missile(m.id),
    })
    flying[m.id] = f
  end
  f.seen = true
  local a = f.actor
  a.x, a.y, a.vx, a.vy = m.x, m.y, 0, 0
  a.facing = m.vx < 0 and -1 or 1
  if p.animate then
    f.phase = next_phase(f.phase, p.anim_speed)
    a:frame(frame_of(f.phase, p.frames))
  end
  -- WeapSprite::CalculateAngle, rotation 0.
  local rot = -math.atan(m.vx, m.vy) - math.pi
  a:gfx({ angle = math.deg(rot) % 360, depth = HOLD_DEPTH })
end)

-- ---------------------------------------------------------- Double Bazooka
--
-- PX's double_bazooka_script. A Double Bazooka shell does not end at the
-- first thing it hits: WA's explosion goes off, a 50-pixel hole is cut
-- (GG->land->MakeHole(50), WA's landscape "apply explosion", as
-- wa.land.dig), and a second shell carries on from there at the first one's
-- speed, a real WA missile of the same slot (new CMissile with the weapon's
-- launch data), so WA flies it with wind and its smoke trail. PX changes
-- three things for it: damage 40, sprite 54 and a 5 s fuse. The port takes
-- the damage and fuse; 54 is a cluster bit (clustlet) in WA 3.8.1, so the
-- second shell keeps the record's bazooka shell (48, missile), as the first
-- does. Its own explosion ends it.
--
-- Not ported: PX's particle trail on top of WA's (pxparticles), and a plain
-- 50/35 blast PX makes when a second shell explodes before its first frame.

local DB_SECOND = { damage = 40, fuse = 5000 }
local DB_HOLE = 50

local db_speed = {}   -- missile id -> { vx, vy } at its last frame
local db_second = {}  -- missile id -> true: a second shell, which ends it
local db_pending = {} -- second shells to launch once the blast is over
local db_shooter      -- the worm that fired it (PX's ClWT / ClWN)

wa.on.missile_frame(function(m)
  if m.weapon == "bazooka" and m.phase == "post" then
    db_speed[m.id] = { m.vx, m.vy }
  end
end)

double_bazooka_explode = function(ev)
  local id = ev.missile
  if not id then
    return
  end
  local speed = db_speed[id]
  db_speed[id] = nil
  if db_second[id] then
    db_second[id] = nil
    return
  end
  if not speed then
    return
  end
  wa.land.dig({ x = ev.x, y = ev.y, radius = DB_HOLE })
  -- Launched after the blast, as PX's comes after super: WA's explosion
  -- would otherwise push it.
  db_pending[#db_pending + 1] = { x = ev.x, y = ev.y, vx = speed[1], vy = speed[2] }
end

wa.on.worm_message(function(worm, msg)
  if msg == wa.msg.FIRE_WEAPON and worm.weapon == "bazooka" then
    db_shooter = worm
  elseif msg == wa.msg.FRAME_FINISH and #db_pending > 0 then
    -- The first worm's frame after the blast; every worm gets one.
    local owner = db_shooter or worm
    for _, p in ipairs(db_pending) do
      local id = wa.weapons.launch({
        weapon = "bazooka", owner = owner, x = p.x, y = p.y, vx = p.vx, vy = p.vy,
        damage = DB_SECOND.damage, fuse = DB_SECOND.fuse,
      })
      db_second[id] = true
    end
    db_pending = {}
  end
end)

-- ------------------------------------------------------------- Chilli Bomb
--
-- PX's pyro_grenades_script (PyroMan), on WA's super banana. When a Chilli
-- Bomb explodes, five more Chillis burst out of it, straight up with a
-- random spread (PX's ShotClustlets): real WA missiles of the same slot,
-- each with damage 30, an 8 s fuse, no countdown, the fire key setting it
-- off, and a burst of fire where it ends. The five do not burst again: a
-- missile PX's script makes has no weapon of its own (weap), so its
-- ExplodeAt skips the Chilli's branch.
--
-- Not ported: PX's particle trail and the sparks while aiming
-- (pxparticles), and the smoke trail's power of 20 on the five. PX also
-- writes the five's changes into the weapon's own launch data, so every
-- later Chilli Bomb flies with them; the port changes the five only.

local CHILLI_CHILD = { count = 5, damage = 30, fuse = 8000 }

local chilli_child = {}   -- missile id -> true: one of the five, which ends it
local chilli_pending = {} -- where the five burst out, once the blast is over
local chilli_shooter      -- the worm that threw it (PX's ClWT / ClWN)

chilli_bomb_explode = function(ev)
  local id = ev.missile
  if not id then
    return
  end
  if chilli_child[id] then
    chilli_child[id] = nil
    return
  end
  chilli_pending[#chilli_pending + 1] = { x = ev.x, y = ev.y }
end

wa.on.worm_message(function(worm, msg)
  if msg == wa.msg.FIRE_WEAPON and worm.weapon == "super_banana" then
    chilli_shooter = worm
  elseif msg == wa.msg.FRAME_FINISH and #chilli_pending > 0 then
    -- After the blast, as the Double Bazooka's second shell.
    local P = 0x10000
    local owner = chilli_shooter or worm
    for _, p in ipairs(chilli_pending) do
      for _ = 1, CHILLI_CHILD.count do
        -- RandomFloat(3, -3), then RandomFloat(-7, -10).
        local vx = wa.random(-3 * P, 3 * P)
        local vy = wa.random(-10 * P, -7 * P)
        local id = wa.weapons.launch({
          weapon = "super_banana", owner = owner, x = p.x, y = p.y, vx = vx, vy = vy,
          damage = CHILLI_CHILD.damage, fuse = CHILLI_CHILD.fuse, countdown = 0,
          explode_on_space = true, explode_into = "fire",
          sprite = 0, -- PX leaves them WA's sprite 0; the chilli is drawn instead
        })
        chilli_child[id] = true
      end
    end
    chilli_pending = {}
  end
end)

-- ------------------------------------------------------------ Nuke Rocket
--
-- PX's nuke_rocket_script, on the mine slot. The scheme's record is a
-- placed weapon that WA fires as a missile (fire type 2, method 2:
-- CreateWeaponProjectile), and it already has every value PX's FireFinal
-- gives its first rocket (a 3 s fuse, damage 0, bias 50, push 70, sound
-- 66). So WA's own shot is PX's first rocket: it fuses on the ground,
-- hissing (sound 66 every 10 frames). When it explodes, a nuke climbs out
-- of it: a real WA missile of the same slot (wa.weapons.launch, as PX's
-- MakeNuke creates a CMissile), silent, with a 1.6 s fuse, bursting into
-- the record's clustlets. For 53 frames it climbs, randomly and jittering
-- sideways, and carries worms and missiles within 17 pixels along; then
-- it brakes. Its explosion adds PX's two 40/40 blasts and sounds 85, 70.
--
-- Not ported: PX's particle trails, and carrying mines, crates, oil drums
-- and bowling balls (their speed is not writable from Lua).

local P16 = 0x10000
local NR_HISS = 66    -- the fusing rocket's hiss, every 10 frames
local NR_CLIMB = 53   -- frames the nuke climbs (PX: "1.1-1.2 second")
local NR_CARRY = 17   -- pixels: what the climbing nuke carries along
local NUKE = { fuse = 1600, sound = 0, explode_into = "clustlets" }
local NUKE_BLAST = { damage = 40, id = 40 } -- PX's DoExplosion(x, y, 40, 40), twice

local nr_first = {}    -- missile id -> frames: a first rocket, fusing
local nr_speed = {}    -- missile id -> { vx, vy } at its last frame
local nr_nuke = {}     -- missile id -> frames flown: a nuke
local nr_climbing = {} -- nuke id -> { x, y, vx, vy }, while it climbs
local nr_pending = {}  -- nukes to launch once the rocket's blast is over
local nr_shooter       -- the worm that fired (PX's ClWT / ClWN)
local nr_expect        -- fired: the next mine-slot missile is the rocket

local function near(ax, ay, bx, by)
  local r = NR_CARRY * P16
  return math.abs(ax - bx) < r and math.abs(ay - by) < r
end

wa.on.missile_frame(function(m)
  local t = nr_nuke[m.id]
  if t ~= nil then
    -- Before WA moves it, as PX's M_FRAME runs before super.
    if m.phase ~= "pre" then
      return
    end
    if t < NR_CLIMB then
      m.vy = m.vy - wa.random(19661, 52429) -- 0.3 to 0.8 a frame
      if t % 2 == 1 then
        m.vx = m.vx + wa.random(-19661, 19661) -- up to 0.3 either way
      end
      nr_climbing[m.id] = { x = m.x, y = m.y, vx = m.vx, vy = m.vy }
      for _, w in ipairs(wa.worms.all()) do
        if near(w.x, w.y, m.x, m.y) then
          w.vx, w.vy = m.vx, m.vy
        end
      end
    else
      nr_climbing[m.id] = nil
      if m.vy < 0 then
        m.vy = m.vy + 13107 -- 0.2: slows the climb without faking gravity
      end
    end
    nr_nuke[m.id] = t + 1
    return
  end
  -- The rocket is the missile WA fires after the fire key. Later ones of
  -- the slot (the nuke's cluster bits) are no rockets.
  if nr_first[m.id] == nil and nr_expect and m.weapon == "mine" then
    nr_first[m.id], nr_expect = 0, false
  end
  if nr_first[m.id] ~= nil then
    if m.phase == "post" then
      nr_speed[m.id] = { m.vx, m.vy }
      local n = (nr_first[m.id] or 0) + 1
      nr_first[m.id] = n
      if n % 10 == 0 and nr_shooter then
        wa.sound.play(nr_shooter, NR_HISS)
      end
    end
    return
  end
  -- Any other missile a climbing nuke passes is carried along.
  if m.phase == "pre" then
    for _, c in pairs(nr_climbing) do
      if near(m.x, m.y, c.x, c.y) then
        m.vx, m.vy = c.vx, c.vy
      end
    end
  end
end)

nuke_rocket_explode = function(ev)
  local id = ev.missile
  if not id then
    return
  end
  if nr_nuke[id] then
    nr_nuke[id], nr_climbing[id] = nil, nil
    local owner = nr_shooter
    if owner then
      wa.sound.play(owner, 85)
      wa.sound.play(owner, 70) -- "louder please :D"
      for _ = 1, 2 do
        wa.actors.spawn({
          sprite = false, x = ev.x, y = ev.y, owner = owner,
          explode = { damage = NUKE_BLAST.damage, id = NUKE_BLAST.id, now = true },
        })
      end
    end
    return
  end
  if nr_first[id] then
    local speed = nr_speed[id] or { 0, 0 }
    nr_first[id], nr_speed[id] = nil, nil
    if nr_shooter then
      wa.sound.play(nr_shooter, "sounds/nuke_rocket_launch.wav")
    end
    -- Launched after the blast, as PX's comes after super.
    nr_pending[#nr_pending + 1] = { x = ev.x, y = ev.y, vx = speed[1], vy = speed[2] }
  end
end

wa.on.worm_message(function(worm, msg)
  if msg == wa.msg.FIRE_WEAPON and worm.weapon == "mine" then
    nr_shooter, nr_expect = worm, true
  elseif msg == wa.msg.FRAME_FINISH and #nr_pending > 0 then
    local owner = nr_shooter or worm
    for _, p in ipairs(nr_pending) do
      local id = wa.weapons.launch({
        weapon = "mine", owner = owner, x = p.x, y = p.y, vx = p.vx, vy = p.vy,
        fuse = NUKE.fuse, sound = NUKE.sound, explode_into = NUKE.explode_into,
      })
      nr_nuke[id] = 0
    end
    nr_pending = {}
  end
end)

-- -------------------------------------------------------------- Helicopter
--
-- PX's helicopter_user_script, on WA's jet pack. While the jet pack runs,
-- the script flies the worm itself from the worm's own move keys, which it
-- then consumes so WA's jet pack neither thrusts nor burns fuel: speed that
-- builds while a key is held and dies away when it is not, fuel that burns
-- with it (not during retreat), and a crash -- an explosion sized by the fuel
-- left and the speed -- when the fuel runs out, the worm reaches water, the
-- turn ends, or it hits something other than a mine faster than a pixel a
-- frame, the ground included: landing slower than that is PX's smooth
-- landing. The worm's body is hidden behind the helicopter, and behind PX's
-- climb-in animation while WA winds the jet pack up; its labels, the fuel
-- counter among them, stay, as with PX's RenderWorm override.
--
-- PX's speeds and factors are fixed point: 1.0 is 0x10000 here, and its
-- arithmetic truncates.

local HELI_FUEL = 100            -- FuelAmount
local HELI_REALISTIC = true      -- gravity and wind act on it, at 0.2
local HELI_EXPLODE_ON_TURN_END = true
local HELI_DEPTH = 0x10000       -- in front of worms and terrain
local FX = 0x10000

local helis = {} -- worm id -> { flying, launch, jumpin, jump_phase, frame, ticks, body, climb }

local function trunc(v)
  return v >= 0 and math.floor(v) or math.ceil(v)
end

local function heli_of(worm)
  local h = helis[worm.id]
  if not h then
    h = { flying = false, launch = false, jumpin = false, jump_phase = 0, frame = 0, ticks = 0 }
    helis[worm.id] = h
  end
  return h
end

local function heli_actor(worm, sheet)
  return wa.actors.spawn({
    sprite = sheet, x = worm.x, y = worm.y, gravity = false,
    collide = false, owner = worm, on = function() end,
  })
end

local function heli_drop_art(h, worm)
  if h.body then h.body:despawn(); h.body = nil end
  if h.climb then h.climb:despawn(); h.climb = nil end
  worm.body_visible = true
end

local HELI_OOPS = {
  [2] = "sounds/helicopter/oops1.wav", [4] = "sounds/helicopter/oops2.wav",
  [6] = "sounds/helicopter/huh.wav", [8] = "sounds/helicopter/poop.wav",
  [10] = "sounds/helicopter/idiot.wav",
}

-- DisableHeli: blow up, sized by the fuel left and the speed, and land.
local function heli_crash(worm, h, sx, sy)
  if not h.flying then
    return
  end
  local speed = (math.abs(sy) + math.abs(sx)) / 2 / FX
  local size = trunc((worm.fuel / FX - 75) / 10 * speed)
  if size < 10 then size = 10 end
  -- The worm's own explosion: a spawn needs an owner, and outside a brain
  -- (from wa.on.contact) there is none to inherit.
  wa.actors.spawn({
    sprite = false, x = worm.x, y = worm.y, gravity = false, collide = false,
    owner = worm, explode = { damage = size * 2, id = size, now = true },
  })
  worm.gravity = FX
  worm.wind = 0
  local oops = HELI_OOPS[wa.random(1, 10)]
  if oops then wa.sound.play(worm, oops) end
  h.flying = false
  heli_drop_art(h, worm)
end

-- One of PX's key responses, towards `dir` (-1 up or left, 1 down or
-- right): a kick that fades as the speed that way reaches 10 pixels a frame.
-- PX: if (SpY > -1) SpY -= 0.2; if (SpY > -4) SpY -= 0.4; ... for up.
local function push(v, dir)
  local s = -dir * v
  if s > -1 * FX then s = s - 0.2 * FX end
  if s > -4 * FX then s = s - 0.4 * FX end
  if s > -8 * FX then s = s - 0.15 * FX end
  if s > -10 * FX then s = s - 0.05 * FX end
  return -dir * s
end

local function heli_frame(worm)
  local h = helis[worm.id]
  local state = worm.state
  -- WS_FIRED: WA winding up the Helicopter; PX shows its climb-in. This is
  -- also where it is armed: once it fires, WA may already have cleared the
  -- worm's selection (its last shot of the Helicopter), and PX decides at
  -- FireFinal, from the weapon actually fired.
  if worm.weapon == "jet_pack" and state == "prefiring" and not (h and h.flying) then
    h = heli_of(worm)
    h.jumpin, h.armed = true, true
    h.jump_phase = h.jump_phase + 0.047
  end
  -- FireFinal: the jet pack it wound up has started.
  if h and h.armed and state == "jetpacking" and not h.flying then
    worm.gravity = HELI_REALISTIC and trunc(0.2 * FX) or 0
    h.flying, h.launch, h.ticks, h.armed = true, true, 0, false
  elseif h and h.armed and not worm.turn then
    h.armed = false -- the turn ended before it fired
  end
  if not h then
    return
  end
  if h.flying then
    local vx, vy = worm.vx, worm.vy
    -- Rotor and radio, while it moves.
    if vx ~= 0 or vy ~= 0 then
      if h.ticks % 47 == 0 then wa.sound.play(worm, "sounds/helicopter/helicopterloop.wav") end
      local radio = wa.random(1, 200)
      if radio % 20 == 0 and radio <= 80 then
        wa.sound.play(worm, "sounds/helicopter/" .. (radio // 20) .. ".wav")
      end
    end
    h.ticks = h.ticks + 1
    if worm.y >= wa.world.water() then
      heli_crash(worm, h, vx, vy)
      return
    end
    if h.launch then
      worm.fuel = HELI_FUEL * FX
      h.jump_phase, h.jumpin, h.launch = 0, false, false
      if HELI_REALISTIC then worm.wind = trunc(0.2 * FX) end
    end
    local k = worm.keys
    local up, down, left, right = k.up, k.down, k.left, k.right
    if not up and not down then vy = vy / 1.105 end
    if not left and not right then vx = vx / 1.105 end
    if up and down then vy = vy / 1.095 end
    if left and right then vx = vx / 1.095 end
    -- Diagonals: PX's lines damp each pair twice.
    for _, d in ipairs({ { up, right }, { up, left }, { down, right }, { down, left } }) do
      if d[1] and d[2] then
        vx, vy = vx * 0.99 * 0.99, vy * 0.99 * 0.99
      end
    end
    h.frame = (h.frame + 1) % 3
    local fuel = worm.fuel
    local burn = wa.world.retreat() == 0
    if burn then fuel = fuel - 0.020 * FX end
    local shift = wa.world.keys().sprint
    if up then
      if burn then fuel = fuel - 0.2 * FX end
      vy = push(vy, -1)
    end
    if down then
      if burn then fuel = fuel - 0.020 * FX end
      vy = push(vy, 1)
    end
    if left then
      if burn then fuel = fuel - 0.1 * FX end
      if not shift then worm.facing = -1 end
      vx = push(vx, -1)
    end
    if right then
      if burn then fuel = fuel - 0.1 * FX end
      if not shift then worm.facing = 1 end
      vx = push(vx, 1)
    end
    worm:clear_keys()
    worm.vx, worm.vy, worm.fuel = trunc(vx), trunc(vy), trunc(fuel)
    if worm.state ~= "jetpacking" then
      if worm.vy == 0 and state ~= "prefiring" and state ~= "teleporting" then
        worm:set_state("sliding")
      end
      worm.gravity, worm.wind = FX, 0
      h.flying = false
      heli_drop_art(h, worm)
      return
    elseif worm.fuel <= 0.1 * FX then
      heli_crash(worm, h, worm.vx, worm.vy)
      return
    end
    if HELI_EXPLODE_ON_TURN_END and not worm.turn then
      heli_crash(worm, h, worm.vx, worm.vy)
      return
    end
  end
  -- What PX draws in the worm's place.
  local f = worm.facing
  if h.flying then
    if h.climb then h.climb:despawn(); h.climb = nil end
    h.body = h.body or heli_actor(worm, "sprites/helicopter/flying")
    local a = h.body
    a.x, a.y, a.vx, a.vy, a.facing = worm.x, worm.y, 0, 0, f
    a:frame(h.frame)
    a:gfx({ angle = math.deg(math.sin(worm.vx / FX / 24)) % 360, depth = HELI_DEPTH })
    worm.body_visible = false
  elseif h.jumpin and state == "prefiring" then
    h.climb = h.climb or heli_actor(worm, "sprites/helicopter/jumpin")
    local a = h.climb
    a.x = worm.x + trunc((f > 0 and -11.5 or 12.5) * FX)
    a.y, a.vx, a.vy, a.facing = worm.y + FX, 0, 0, f
    a:frame(math.min(math.floor(h.jump_phase * 23), 22))
    a:gfx({ depth = HELI_DEPTH })
    worm.body_visible = false
  elseif h.body or h.climb then
    h.jumpin, h.jump_phase = false, 0
    heli_drop_art(h, worm)
  end
end

wa.on.worm_message(function(worm, msg)
  if msg == wa.msg.FRAME_FINISH then
    heli_frame(worm)
  end
end)

-- Collide: hitting anything but a mine faster than a pixel a frame crashes
-- it, the ground included -- a slow landing is PX's smooth landing -- judged
-- on the speed before WA exchanged velocities.
if wa.on.contact then
  wa.on.contact(function(worm, other, c)
    local h = helis[worm.id]
    if h and h.flying and other.kind ~= "mine"
        and (math.abs(c.vx) > FX or math.abs(c.vy) > FX) then
      heli_crash(worm, h, c.vx, c.vy)
    end
  end)
end

-- --------------------------------------------------------- Hot Air Balloon
--
-- PX's balloon_s (r2_balloon by rafa''2, modified by 0rang3), on WA's
-- parachute. While the parachute is open, the worm's gravity is turned
-- upside down, so it rises; the balloon pops -- gravity back -- when the
-- parachute closes, at a turn change, or in water. The worm's body is
-- hidden behind the balloon, drawn in its team's colour, and the worm in its
-- basket, as PX's RenderWorm override draws them.

local BALLOON_DEPTH = 0x10001    -- behind the basket, in front of worms
local BASKET_DEPTH = 0x10000
-- PX's GetTeamColorRGB, by WA's colour index (worm.alliance, 0 red .. 5 cyan).
-- PX adds it to its dark grey balloon (SetColorMod mode 8); the GPU tint
-- multiplies, so the pack's balloon art is PX's lightened to white, and the
-- team colour shows at full strength.
local TEAM_RGB = { 0xFF8080, 0x0096FF, 0x00D000, 0xFFFF40, 0xE800E8, 0x50FFFF }

local balloons = {} -- worm id -> { active, gravity, ticks, last_weapon, balloon, basket }

local function balloon_of(worm)
  local b = balloons[worm.id]
  if not b then
    b = { active = false, gravity = 0, ticks = 0 }
    balloons[worm.id] = b
  end
  return b
end

local function balloon_sound(worm, name, n)
  wa.sound.play(worm, "sounds/balloon/" .. name .. wa.random(1, n) .. ".wav")
end

-- StopBalloon: gravity back, and a pop.
local function balloon_stop(worm, b)
  if not b.active then
    return
  end
  worm.gravity = -b.gravity
  b.active, b.ticks = false, 0
  if b.balloon then b.balloon:despawn(); b.balloon = nil end
  if b.basket then b.basket:despawn(); b.basket = nil end
  worm.body_visible = true
  balloon_sound(worm, "pop", 4)
end

local function balloon_frame(worm)
  local b = balloon_of(worm)
  local state = worm.state
  -- FireFinal(Hot Air Balloon): WA opens its parachute straight away and
  -- clears the selection as it does ("none"), so it is the one the worm had
  -- the frame before.
  local weapon = worm.weapon
  if weapon == nil or weapon == "none" then
    weapon = b.last_weapon
  end
  if not b.active and state == "parachuting" and not b.was_parachuting
      and weapon == "bungee" then
    b.active, b.ticks = true, 0
    balloon_sound(worm, "inflate", 3)
  end
  b.was_parachuting = state == "parachuting"
  b.last_weapon = worm.weapon
  if b.active then
    if state == "parachuting" and worm.turn and worm.y < wa.world.water() then
      worm.gravity = b.gravity
    else
      if state == "standing" then
        worm:set_state("sliding")
      end
      balloon_stop(worm, b)
      return
    end
    b.ticks = b.ticks + 1
    -- DrawBalloonWorm: the balloon above, in the team's colour, and the worm
    -- in its basket, whose art faces left.
    local f = worm.facing
    local function art(sheet)
      return wa.actors.spawn({
        sprite = sheet, x = worm.x, y = worm.y, gravity = false,
        collide = false, owner = worm, on = function() end,
      })
    end
    b.balloon = b.balloon or art("sprites/balloon/balloon")
    b.basket = b.basket or art("sprites/balloon/basket")
    local x = worm.x + 6 * f * FX
    b.balloon.x, b.balloon.y, b.balloon.vx, b.balloon.vy = x, worm.y - 43 * FX, 0, 0
    b.balloon:frame(math.min((b.ticks % 200) * 16 // 200, 15))
    b.balloon:gfx({ tint = 0xFF000000 | (TEAM_RGB[(worm.alliance or 0) + 1] or 0xFFFFFF),
      depth = BALLOON_DEPTH })
    b.basket.x, b.basket.y, b.basket.vx, b.basket.vy = x, worm.y + 3 * FX, 0, 0
    b.basket.facing = -f
    b.basket:frame(math.min((b.ticks % 80) * 17 // 80, 16))
    b.basket:gfx({ depth = BASKET_DEPTH })
    worm.body_visible = false
  else
    -- Kept up to date while it is not flying: the gravity to turn over.
    b.gravity = -worm.gravity
  end
end

wa.on.worm_message(function(worm, msg)
  if msg == wa.msg.FRAME_FINISH then
    balloon_frame(worm)
  end
end)

-- M_TURNBEGIN: any balloon still up pops.
wa.on.turn_start(function()
  for _, worm in ipairs(wa.worms.all()) do
    local b = balloons[worm.id]
    if b and b.active then
      balloon_stop(worm, b)
    end
  end
end)

-- ------------------------------------------------------------- Hang-Glider
--
-- PX's paratest (utility_hangglider_render), on WA's parachute. A worm that
-- opens the parachute with the Hang-Glider flies PX's glider: gravity at
-- 0.75, the wind blowing along the wing's up side (x3), the speed across the
-- wing damped, and the nose turning towards the flight path. Up and down
-- turn the nose, faster the faster it flies; left and right nudge it. It
-- stops gliding just before it would run into something (PX's
-- WS_AFTERROPE; here WA's sliding, as the Helicopter's end). While it
-- glides, the worm's body is hidden behind the glider art, which carries the
-- worm; on landing, the glider's own pack-away plays in place of WA's
-- parachute's (PX swaps sheet 289, wparbak, for it).
--
-- PX's speeds and angles are pixels per frame and radians; WA's gravity,
-- wind and worm speeds are 16.16.

local GLIDER_GRAVITY = 0.75           -- GliderGravityFactor
local GLIDER_WIND = 3.0               -- GliderWindFactor
local GLIDER_FRICTION = 0.25          -- GliderFriction
local GLIDER_TURN = 0.06              -- GliderMaxAngularVelocity
local GLIDER_TURN_SPEED = 20.0        -- GliderMaxTurningSpeed
local GLIDER_ANIM = 0.04              -- GliderAnimSpeed
local GLIDER_LERP = 0.03              -- GliderRotationLerp
local GLIDER_PUSH = 0.02              -- GliderMoveAcceleration
local GLIDER_MAX_ANGLE = 1.5          -- about 86 degrees either way
local GLIDER_DEPTH = 0x10000          -- in front of worms and terrain
-- wgldbak: 6 frames, loaded at 24 frames a second; WA runs 50.
local GLIDER_PACK_FRAMES, GLIDER_PACK_FPS = 6, 24
local GLIDER_PI = 3.141593

local gliders = {} -- worm id -> { enabled, deployed, ang, target, cycle, sx, sy, art, pack, pack_t }

local function glider_of(worm)
  local g = gliders[worm.id]
  if not g then
    g = { enabled = false, deployed = false, ang = 0, target = 0, cycle = 0, sx = 0, sy = 0 }
    gliders[worm.id] = g
  end
  return g
end

-- utils' NormalizeAngle and LerpAngle.
local function normalize_angle(a)
  while a > GLIDER_PI do a = a - 6.283186 end
  while a <= -GLIDER_PI do a = a + 6.283186 end
  return a
end

local function lerp_angle(c, a, b)
  a = normalize_angle(a)
  b = a + normalize_angle(b - a)
  return normalize_angle(a + (b - a) * c)
end

local function glider_art(worm, sheet)
  return wa.actors.spawn({
    sprite = sheet, x = worm.x, y = worm.y, gravity = false,
    collide = false, owner = worm, on = function() end,
  })
end

local function glider_drop_art(worm, g)
  if g.art then g.art:despawn(); g.art = nil end
  if g.pack then g.pack:despawn(); g.pack = nil end
  worm.body_visible = true
end

-- TraceMask from the worm to where it is heading: the terrain, and anything
-- else in the way by the Sniper Rifle's estimate of its mask.
local function glider_blocked(worm, sx, sy)
  local P = 0x10000
  local x1, y1 = worm.x + trunc(1.1 * sx * P), worm.y + trunc(1.1 * sy * P)
  if wa.land.trace(worm.x, worm.y, x1, y1) then
    return true
  end
  local len = math.sqrt(sx * sx + sy * sy) * 1.1
  if len == 0 then
    return false
  end
  local dx, dy = sx * 1.1 / len, sy * 1.1 / len
  for _, s in ipairs(STOPPERS) do
    local list, r = s[1], s[2]
    if list and list.all then
      for _, o in ipairs(list.all()) do
        if o.id ~= worm.id then
          local ox, oy = (o.x - worm.x) / P, (o.y - worm.y) / P
          local t = ox * dx + oy * dy
          if t > 0 and t < len and math.abs(ox * dy - oy * dx) < r then
            return true
          end
        end
      end
    end
  end
  return false
end

-- CWormGlider::Move: up and down turn the nose, left and right push.
local function glider_keys(worm, g)
  local k = worm.keys
  local speed = math.sqrt(g.sx * g.sx + g.sy * g.sy) / GLIDER_TURN_SPEED
  -- One message per held key, so both of a pair act together.
  if k.up then
    g.ang = math.max(g.ang - GLIDER_TURN * math.min(speed, 1), -GLIDER_MAX_ANGLE)
  end
  if k.down then
    g.ang = math.min(g.ang + GLIDER_TURN * math.max(math.min(speed, 1), 0.5), GLIDER_MAX_ANGLE)
  end
  if k.left then g.sx = g.sx - GLIDER_PUSH end
  if k.right then g.sx = g.sx + GLIDER_PUSH end
end

-- CWormGlider::Think's physics, once deployed.
local function glider_think(worm, g)
  local P = 0x10000
  local f = worm.facing
  local ang = f < 0 and g.ang or GLIDER_PI - g.ang
  local fwd_x, fwd_y = -math.cos(ang), math.sin(ang)
  local up_x, up_y
  if f < 0 then up_x, up_y = -fwd_y, fwd_x else up_x, up_y = fwd_y, -fwd_x end
  local sx, sy = g.sx, g.sy
  sy = sy + wa.world.gravity() / P * GLIDER_GRAVITY
  local wind = up_x * wa.world.wind() / P * GLIDER_WIND
  sx, sy = sx + wind * up_x, sy + wind * up_y
  local up_vel = sx * up_x + sy * up_y
  sx, sy = sx - up_x * up_vel * GLIDER_FRICTION, sy - up_y * up_vel * GLIDER_FRICTION
  -- The nose turns towards the flight path, never straight up or down.
  local target = f < 0 and math.atan(sy, -sx) or math.atan(sy, sx)
  target = normalize_angle(target)
  g.target = math.max(-GLIDER_MAX_ANGLE, math.min(GLIDER_MAX_ANGLE, target))
  g.ang = lerp_angle(GLIDER_LERP, g.ang, g.target)
  g.cycle = math.min(g.cycle + GLIDER_ANIM, 1)
  if glider_blocked(worm, sx, sy) then
    g.blocked = true
    worm:set_state("sliding")
  end
  g.sx, g.sy = sx, sy
  worm.vx, worm.vy = trunc(sx * P), trunc(sy * P)
end

local function glider_frame(worm)
  -- Only worms that have held the Hang-Glider.
  local g = gliders[worm.id]
  if not g then
    if worm.weapon ~= "parachute" then
      return
    end
    g = glider_of(worm)
  end
  local state = worm.state
  local P = 0x10000
  if state ~= "parachuting" then
    -- Which parachute the worm opens next: PX checks the weapon only while
    -- the worm is not already under one.
    if worm.weapon == "parachute" then
      g.enabled = true
    elseif worm.weapon == "bungee" then
      g.enabled = false -- the Hot Air Balloon
    end
    if g.deployed then
      g.deployed = false
      glider_drop_art(worm, g)
      wa.sound.play(worm, "sounds/hang_glider/hangclose.wav")
      -- Landed on its feet: WA packs the parachute away (wparbak), which
      -- PX draws as the glider's pack-away.
      if not g.blocked and state == "standing" and worm.y < wa.world.water() then
        g.pack, g.pack_t = glider_art(worm, "sprites/hang_glider/pack"), 0
      end
      g.blocked = false
    end
    if g.pack then
      local frame = g.pack_t * GLIDER_PACK_FPS // 50
      if frame >= GLIDER_PACK_FRAMES or worm.state ~= "standing" then
        glider_drop_art(worm, g)
      else
        g.pack.x, g.pack.y, g.pack.vx, g.pack.vy = worm.x, worm.y, 0, 0
        g.pack.facing = -worm.facing -- its art faces left, as WA's worms do
        g.pack:frame(frame)
        g.pack:gfx({ depth = GLIDER_DEPTH })
        worm.body_visible = false
        g.pack_t = g.pack_t + 1
      end
    end
    -- Its speed carries over into the glide.
    g.sx, g.sy = worm.vx / P, worm.vy / P
    return
  end
  if not g.enabled then
    return -- a plain parachute, or the balloon
  end
  if not g.deployed then
    g.deployed, g.ang, g.target, g.cycle = true, 0, 0, 0
    if g.pack then g.pack:despawn(); g.pack = nil end
    wa.sound.play(worm, "sounds/hang_glider/hangopen.wav")
  end
  glider_keys(worm, g)
  glider_think(worm, g)
  -- CWormGlider::Render, in the worm's place.
  local f = worm.facing
  g.art = g.art or glider_art(worm, "sprites/hang_glider/glider")
  local a = g.art
  a.x, a.y, a.vx, a.vy, a.facing = worm.x, worm.y, 0, 0, -f
  a:frame(math.min(math.floor(g.cycle * 10), 9))
  a:gfx({ angle = math.deg(f * g.ang) % 360, depth = GLIDER_DEPTH })
  worm.body_visible = false
end

if wa.world.gravity and wa.world.wind then
  wa.on.worm_message(function(worm, msg)
    if msg == wa.msg.FRAME_FINISH then
      glider_frame(worm)
    end
  end)
end

-- --------------------------------------------------------------- Swim Suit
--
-- PX's swimsuit_SCRIPT (StepS; swim sprites by Team17) with fastswim_SCRIPT
-- and swim_suit_diving_s (PyroMan), on WA's laser sight. Using it puts the
-- suit on (or, out of the water, takes it off): WA's laser sight never
-- switches on, as PX's FireFinal never calls super. A worm in the suit that
-- falls into the water splashes and swims instead of drowning: held in WA's
-- bungee state with no gravity, moved by its own four keys (up to 2.5 pixels
-- a frame times the swim speed, gliding to a stop when they are let go),
-- turned by left and right unless Shift is held. Enter does nothing while it
-- swims. Out of the water it flies on as from a jump; too deep (180 pixels
-- under the water, or the bottom of a cavern) or knocked out of those states,
-- the suit gives out and it sinks. Fast Walk switches the swim speed between
-- 2 and 6 for the turn. Missiles in the water can hit a swimming worm: they
-- blow up on it (damage 100, blast 50).
--
-- Drawn in the worm's place: the swim or, when still, the float animation,
-- and a bubble around the worm while it wears the suit.
--
-- Not ported: PX's ghost jet and battyswim interplay (other libraries), the
-- Ninja Rope workaround after leaving the water (the Jump is on the rope's
-- slot here), inverted controls, and the team message on putting it on.

local SWIM_CAP = 2.5          -- pixels a frame, times the swim speed
local SWIM_PUSH = 0.1
local SWIM_DRAG = 1.05
local SWIM_STILL = 0.05
local SWIM_FLOAT_STEP = 0.0099
local SWIM_DEPTH = 180        -- how far under the water the suit holds
local SWIM_SUIT_MASK = 134342 -- 0x20CC6: the worm's 0x420CC6 without SWIM_WATER
-- Bit 22 of a collision mask: WA's water acts on what has it (0x4FDE20), and
-- sinks or drowns it. The suit takes it off; a missile sinking in the water
-- has only it.
local SWIM_WATER = 0x400000
local SWIM_MISSILE_MASK = 0x40007C -- a missile in the water that hits worms
local SWIM_SPLASH = 57        -- WA's sound
local SWIM_BODY_DEPTH = 0x10000
local SWIM_RING_DEPTH = 0x10001
-- Ring sheet is 50×50; wa.draw.quad corners are centred on the worm like a:gfx.
local SWIM_RING_HALF = 25 * 0x10000

local swim_speed = 2          -- fastswim: Fast Walk switches 2 and 6
local swim_in_game = false    -- SwimInGame: someone has worn the suit
local swimmers = {} -- worm id -> { suit, plopready, plopped, floating, plophase, flophase, fmult, keys, body }

local function swimmer_of(worm)
  local s = swimmers[worm.id]
  if not s then
    s = { suit = false, plopready = false, plopped = false, floating = false,
      plophase = 0, flophase = 0, fmult = 5, keys = {} }
    swimmers[worm.id] = s
  end
  return s
end

local function swim_drop_art(worm, s)
  if s.body then s.body:despawn(); s.body = nil end
  worm.body_visible = true
end

-- The suit comes off: gravity back, the water's bit back in its mask, and
-- sinking if it gave out in the water.
local function suit_off(worm, s, sink)
  s.suit, s.plopready, s.plopped, s.floating = false, false, false, false
  worm.gravity = FX
  worm.collision_mask = worm.collision_mask | SWIM_WATER
  swim_drop_art(worm, s)
  if sink then
    worm:set_state("sinking")
  end
end

-- One step towards the cap on a held key, as PX's: while under it, a push;
-- past it, back to it.
local function swim_push(v, dir, cap)
  if dir > 0 then
    if v < cap then return v + SWIM_PUSH * swim_speed end
    return cap
  end
  if v > -cap then return v - SWIM_PUSH * swim_speed end
  return -cap
end

local function swim_frame(worm)
  local s = swimmers[worm.id]
  if not s or not s.suit then
    return
  end
  local P = 0x10000
  local water = wa.world.water()
  local cap = SWIM_CAP * swim_speed
  if worm.y >= water and s.plopready and worm.state ~= "teleporting" then
    wa.sound.play(worm, SWIM_SPLASH)
    s.plopready, s.plopped = false, true
    worm.gravity = 0
    worm.vx = math.min(worm.vx, trunc(cap * P))
    worm.vy = math.min(worm.vy, trunc(cap * P))
    worm:set_state("bungee")
    s.plophase = 0
  end
  if s.plopped then
    local vx, vy = math.min(worm.vx / P, cap), math.min(worm.vy / P, cap)
    local held = s.keys
    local still = math.abs(vx) <= SWIM_STILL * swim_speed and math.abs(vy) <= SWIM_STILL * swim_speed
    if still and not (held.left or held.up or held.down or held.right) then
      -- Floating: the float animation, back and forth.
      s.floating = true
      s.flophase = s.flophase + SWIM_FLOAT_STEP * s.fmult
      if s.flophase >= 0.99 and s.fmult == 5 then
        s.flophase, s.fmult = 0.99, -5
      elseif s.flophase <= 0 and s.fmult == -5 then
        s.flophase, s.fmult = 0, 5
      end
    elseif vx ~= 0 and vy ~= 0 then
      -- Swimming: the stroke follows the faster of the two directions.
      s.floating = false
      if math.abs(vx) >= math.abs(vy) then
        s.plophase = s.plophase + SWIM_FLOAT_STEP * vx * worm.facing
      else
        s.plophase = s.plophase - SWIM_FLOAT_STEP * vy
      end
    elseif vx ~= 0 then
      s.floating = false
      s.plophase = s.plophase + SWIM_FLOAT_STEP * vx
    elseif vy ~= 0 then
      s.floating = false
      s.plophase = s.plophase - SWIM_FLOAT_STEP * vy
    end
    if s.plophase >= 1 or s.plophase <= -1 then
      s.plophase = 0
    end
    local k = worm.keys
    local up, down, left, right = k.up, k.down, k.left, k.right
    if up == down then vy = vy / SWIM_DRAG end
    if left == right then vx = vx / SWIM_DRAG end
    if up then vy = swim_push(vy, -1, cap) end
    if down then vy = swim_push(vy, 1, cap) end
    local shift = wa.world.keys().sprint
    if left then
      if not shift then worm.facing = -1 end
      vx = swim_push(vx, -1, cap)
    end
    if right then
      if not shift then worm.facing = 1 end
      vx = swim_push(vx, 1, cap)
    end
    s.keys = { up = up, down = down, left = left, right = right }
    worm:clear_keys()
    worm.vx, worm.vy = trunc(vx * P), trunc(vy * P)
    -- Out of the water: on through the air, as from a jump.
    if worm.y < water then
      if worm.state ~= "teleporting" then
        worm:set_state("sliding")
      end
      s.floating = false
      worm.gravity = FX
      s.plopready, s.plopped = true, false
    end
    -- Knocked out of its states, or too deep: the suit gives out.
    local state = worm.state
    local y, w = worm.y / P, water / P
    local deep
    if not wa.world.cavern() then
      deep = y > w + SWIM_DEPTH
    elseif w > 610 then
      deep = y > w + SWIM_DEPTH
    else
      deep = y > 768
    end
    if (state ~= "bungee" and state ~= "parachuting" and state ~= "sliding" and state ~= "teleporting")
        or deep then
      suit_off(worm, s, true)
      return
    end
  end
  -- Between turns, a worm out of the water takes the suit off.
  if not current_worm() and worm.y < water then
    suit_off(worm, s, false)
    return
  end
  -- RenderWorm: in the water, the swim or float animation in the worm's
  -- place (its art faces left). The bubble is drawn at render time below.
  local function art(sheet)
    return wa.actors.spawn({
      sprite = sheet, x = worm.x, y = worm.y, gravity = false,
      collide = false, owner = worm, on = function() end,
    })
  end
  if s.plopped and worm.state ~= "teleporting" then
    local sheet = s.floating and "sprites/swim_suit/float" or "sprites/swim_suit/swim"
    if s.body and s.body_sheet ~= sheet then
      s.body:despawn()
      s.body = nil
    end
    s.body = s.body or art(sheet)
    s.body_sheet = sheet
    local phase = s.floating and s.flophase or s.plophase
    s.body.x, s.body.y, s.body.vx, s.body.vy = worm.x, worm.y, 0, 0
    s.body.facing = -worm.facing
    s.body:frame(math.floor((phase % 1) * 20) % 20)
    s.body:gfx({ depth = SWIM_BODY_DEPTH })
    worm.body_visible = false
  elseif s.body then
    s.body:despawn()
    s.body = nil
    worm.body_visible = true
  end
end

-- Bubble while the suit is worn: draw-only, from the live worm position each
-- rendered frame (keeps the 16.16 fraction). A follower LuaActor + a:gfx was
-- pixel-snapped and could wobble when airborne.
if wa.on.draw then
  wa.on.draw(function()
    for _, worm in ipairs(wa.worms.all()) do
      local s = swimmers[worm.id]
      if s and s.suit then
        local x, y, h = worm.x, worm.y, SWIM_RING_HALF
        wa.draw.quad({
          points = {
            { x - h, y - h }, { x + h, y - h }, { x + h, y + h }, { x - h, y + h },
          },
          sprite = "sprites/swim_suit/ring",
          depth = SWIM_RING_DEPTH,
        })
      end
    end
  end)
end

wa.on.worm_message(function(worm, msg)
  if msg == wa.msg.FRAME_FINISH then
    swim_frame(worm)
  elseif msg == wa.msg.JUMP then
    -- M_ENTER: no jumping while it swims.
    local s = swimmers[worm.id]
    if s and s.plopped then
      return "eat"
    end
  elseif msg == wa.msg.FIRE_WEAPON then
    if worm.weapon == "fast_walk" then
      swim_speed = swim_speed ~= 6 and 6 or 2
    elseif worm.weapon == "laser_sight" then
      -- FireFinal(Swim Suit), in place of WA's laser sight.
      local s = swimmer_of(worm)
      if not s.suit then
        wa.sound.play(worm, "sounds/swim_suit/putting_on_ssuit.wav")
        s.suit, s.plopready = true, true
        swim_in_game = true
        worm.collision_mask = SWIM_SUIT_MASK
      elseif worm.y < wa.world.water() then
        suit_off(worm, s, false)
      end
      worm:ammo("laser_sight", -1)
      return "eat"
    end
  end
end)

-- fastswim: the swim speed is 2 again every turn.
wa.on.turn_start(function()
  swim_speed = 2
end)

-- A missile in the water hits worms too, once anyone has worn the suit.
wa.on.missile_frame(function(m)
  if swim_in_game and m.phase == "pre" and m.collision_mask == SWIM_WATER then
    m.collision_mask = SWIM_MISSILE_MASK
  end
end)

-- CMissile::Collide: such a missile blows up on a swimming worm, and is gone
-- (sent below the water, where WA frees it).
if wa.on.contact then
  wa.on.contact(function(worm, other)
    local s = swimmers[worm.id]
    if s and s.plopped and other.kind == "missile" then
      wa.actors.spawn({
        sprite = false, x = other.x, y = other.y, gravity = false, collide = false,
        owner = worm, explode = { damage = 100, id = 50, now = true },
      })
      other.y = wa.world.water() + 0x10000 * 4096
    end
  end)
end

-- ---------------------------------------------- Wind Changer, Gravity Control
--
-- PX's wind_changer_script (ravander, improved by 0rang3) and
-- gravity_control_script (DabbyB, edited by 0rang3). Both records are one of
-- WA's turn utilities (subtype 19) with an index WA does not use (8), so WA
-- fires them as a utility that does nothing, spending the shot as usual, and
-- the script does the work.
--
-- Wind Changer, on the surrender's slot: while it is selected, 0..9 choose
-- the force; firing it sets the wind to force x 0.0317 towards where the
-- worm faces, through WA's own wind change, so the clouds and the wind bar
-- follow. Gravity Control, on low gravity's slot: 1..5 choose 0.3, 0.5, 1,
-- 1.7 or 2.4 times the match's gravity; firing it holds WA's gravity there
-- until the next turn. Fired with nothing chosen it does not fire (PX gives
-- the shot back).
--
-- Differences: a HUD line says which keys to press and what is chosen, in
-- place of PX's team messages; and PX also puts the gravity back after 10 s
-- with the turn clock stopped, which needs the turn clock (not ported).

local WIND_STEP = 0.0317       -- wind per point of force (PX's), a turn's wind is up to about 0.29
local GRAVITY_FACTORS = { 0.3, 0.5, 1.0, 1.7, 2.4 }
local GRAVITY_NAMES = { "Very Low Gravity", "Low Gravity", "Normal Gravity", "High Gravity", "Very High Gravity" }

local wind_force = 0          -- wf
local gravity_choice          -- TransformedGravity's index, until fired
local gravity_initial         -- InitialGravity: the match's
local gravity_factor          -- ModulatedGravity while Gravity Control is on
local last_digit              -- KeyPressedNow: a digit counts when it goes down

local function world_physics_frame(worm)
  gravity_initial = gravity_initial or wa.world.gravity()
  if not worm.turn then
    return
  end
  local digit = wa.world.keys().digit
  local pressed = digit ~= nil and digit ~= last_digit
  last_digit = digit
  if not pressed then
    return
  end
  if worm.weapon == "surrender" then
    wind_force = digit
    wa.sound.play(worm, 107)
  elseif worm.weapon == "low_gravity" and digit >= 1 and digit <= 5 then
    gravity_choice = digit
    wa.sound.play(worm, 92)
  end
end

wa.on.worm_message(function(worm, msg)
  if msg == wa.msg.FRAME_FINISH then
    world_physics_frame(worm)
  elseif msg == wa.msg.FIRE_WEAPON and worm.weapon == "surrender" then
    -- FireFinal(Wind Changer): breeze for none, a calm wind up to 5, strong
    -- above; towards where the worm faces.
    local f = wind_force
    wa.sound.play(worm, f == 0 and "sounds/wind_changer/breeze.wav"
      or f < 6 and "sounds/wind_changer/calm_wind.wav" or "sounds/wind_changer/strong_wind.wav")
    wa.world.set_wind(trunc(f * WIND_STEP * FX) * worm.facing)
  elseif msg == wa.msg.FIRE_WEAPON and worm.weapon == "low_gravity" then
    if not gravity_choice then
      wa.sound.play(worm, "sounds/gravity_control/error.wav")
      return "eat"
    end
    gravity_initial = gravity_initial or wa.world.gravity()
    gravity_factor, gravity_choice = GRAVITY_FACTORS[gravity_choice], nil
    wa.sound.play(worm, "sounds/gravity_control/activate.wav")
    wa.world.set_gravity(trunc(gravity_initial * gravity_factor))
  end
end)

-- M_TURNBEGIN: the match's gravity back.
wa.on.turn_start(function()
  if gravity_factor then
    gravity_factor = nil
    wa.world.set_gravity(gravity_initial)
  end
  gravity_choice = nil
end)

if wa.on.hud then
  wa.on.hud(function()
    local worm = current_worm()
    if not worm then
      return
    end
    if worm.weapon == "surrender" then
      wa.hud.line(string.format("Wind Changer: force %d (keys 0-9), then Space", wind_force))
    elseif worm.weapon == "low_gravity" then
      wa.hud.line("Gravity Control: " .. (gravity_choice and GRAVITY_NAMES[gravity_choice]
        or "choose 1-5") .. ", then Space")
    end
  end)
end

-- ------------------------------------------------------------------ Jump
--
-- PX's jumpscript (utility_jump). Its record throws like a grenade, but
-- nothing leaves the worm: FireFinal gives the worm the shot's own speed --
-- the aim and the charge -- and plays the team's "Jump" line. The worm keeps
-- its aim posture, eyes on the crosshair, until it jumps.
--
-- Differences: PX shows WA's wjump while the charge builds
-- (SetAnimEx(269, FirePower)), which looks ahead rather than along the aim;
-- it also mutes the worm's "Fire!" and "Watch this" lines while the Jump is
-- selected, and stops a fuse and bounce being chosen for it.

-- The first team's "Jump1" speech: WA loads each team's 54 lines in turn
-- after its own sounds, so a worm's is 54 on per team (PX's PlaySoundBank(150)).
local JUMP_SPEECH, SPEECH_LINES = 150, 54

jump_fire = function(fire)
  local worm = fire.worm
  worm:set_state("sliding")
  worm.vx, worm.vy = fire.vx, fire.vy
  wa.sound.play(worm, JUMP_SPEECH + SPEECH_LINES * (worm.team - 1))
end

-- ----------------------------------------------------------------- pools

-- Offensive: PX's `Weapons`, 29 entries.
local OFFENSIVE = {
  "bazooka",          -- Double Bazooka
  "homing_missile",   -- Igniter
  "mortar",           -- S.M.A.R.T Bomb
  "homing_pigeon",    -- Blaster Worm
  "sheep_launcher",   -- Burning Sheep Launcher
  "grenade",          -- Sticky Bomb
  "cluster_bomb",     -- Windy Cluster
  "banana_bomb",      -- Super Gravedigger
  "battle_axe",       -- Thumper Nade
  "earthquake",       -- Electric Grenade
  "dynamite",         -- Dynamite
  "mine",             -- Nuke Rocket
  "sheep",            -- Pogo Sheep
  "aqua_sheep",       -- Ghost Sheep
  "super_banana",     -- Chilli Bomb
  "holy_grenade",     -- Hellish Hand-Grenade
  "petrol_bomb",      -- Valyrian Fire
  "skunk",            -- Remote Roller
  "ming_vase",        -- Priceless Ming Vase
  "mad_cow",          -- Cow Launcher
  "old_woman",        -- Old Woman Launcher
  -- Not dealt on cavern maps:
  "salvation_army",   -- Ferret
  "air_strike",       -- Mortar Strike
  "mail_strike",      -- Pigeon Strike
  "mine_strike",      -- Submarine Attack
  "mole_squadron",    -- Gravler Strike
  "mb_bomb",          -- Banana Express
  "sheep_strike",     -- Bowling Ball Strike
  "carpet_bomb",      -- Thumper Nade Strike
}

-- Second weapon: PX's `NotWeapons`, 19 entries.
local SECOND = {
  "fire_punch",         -- Fire Jump
  "dragon_ball",        -- Sentry Laser
  "kamikaze",           -- Sentry Gun
  "prod",               -- Javelin
  "girder",             -- Baseball Bat
  "baseball_bat",       -- Electromagnet
  "shotgun",            -- Real Shotgun
  "handgun",            -- Sniper Rifle
  "uzi",                -- Laser Gun
  "minigun",            -- Burst Rifle
  "longbow",            -- Shadow-Bolt
  "blow_torch",         -- BlowTorch
  "pneumatic_drill",    -- Super Drill
  "scales_of_justice",  -- Portal Gun
  "armageddon",         -- Ice Arrow
  "flame_thrower",      -- Flame Thrower
  -- Not dealt on cavern maps:
  "nuclear_test",       -- Reinforcement
  "donkey",             -- Crate Strike
  "napalm_strike",      -- Lightning Strike
}

-- Movement: PX's `MoveWeapons`, 7 entries, all dealt on every map.
local MOVEMENT = {
  "girder_pack",   -- 3 Girder Pack
  "ninja_rope",    -- Jump
  "parachute",     -- Hang-Glider
  "teleport",      -- Super Tele
  "jet_pack",      -- Helicopter
  "low_gravity",   -- Gravity Control
  "laser_sight",   -- Swim Suit
}

-- On cavern maps PX draws RandomInt(0,20) and RandomInt(0,15) instead of the
-- whole lists: the first 21 offensive and first 16 second weapons. What that
-- leaves out is what comes from the sky, plus the Ferret.
local CAVE_OFFENSIVE = 21
local CAVE_SECOND = 16

-- The slots Highlander never pools -- Kamikaze Rocket, Gravler, Hot Air
-- Balloon, Skip Go/Surrender, Wind Changer, Muahaha 3, Weapon Crate, Cluster
-- Bomb, Fast Walk, Teleport, Skunk, Crate Spy, Mole Bomb, Crate Shower -- keep
-- whatever ammo the scheme gives them, except the Hot Air Balloon and the
-- Wind Changer, which start_turn sets to 3 and 1.

-- Every slot this pack owns, in a fixed order. Zeroing walks this list, so it
-- must not depend on pairs() order: Lua's string hashing is seeded per
-- process, and a different order on each peer is a different sequence of
-- writes.
local POOLED = {}
for _, pool in ipairs({ OFFENSIVE, SECOND, MOVEMENT }) do
  for _, name in ipairs(pool) do
    POOLED[#POOLED + 1] = name
  end
end

-- ----------------------------------------------------------------- state

-- The engine store is keyed by stable worm id (team * 16 + index), never by
-- entity address. It is virtual: WA's physical ammo is still alliance-shared
-- and is materialized from one worm's inventory at turn start.
local arsenal = wa.inventory.create({ id = "arsenal", slots = POOLED })
local dealt = {}

local function describe(list)
  if not list or #list == 0 then
    return "(nothing)"
  end
  return table.concat(list, ", ")
end

-- ----------------------------------------------------------------- rules

local function first(pool, n)
  local out = {}
  for i = 1, n do
    out[i] = pool[i]
  end
  return out
end

-- One from each pool, dealt to a worm on the first message it receives -- as
-- PX does on each worm's first M_FRAME. Dealing everyone at once on the very
-- first message would assume every worm already exists by then; this makes no
-- such assumption. Worms receive messages in WA's own entity order, which is
-- the same on every peer, so the draws still come out of WA's RNG in the same
-- sequence everywhere.
local function deal(worm)
  local cave = wa.world.cavern()
  arsenal:deal(worm, cave and first(OFFENSIVE, CAVE_OFFENSIVE) or OFFENSIVE, 1)
  arsenal:deal(worm, cave and first(SECOND, CAVE_SECOND) or SECOND, 1)
  arsenal:deal(worm, MOVEMENT, 1)
  dealt[worm.id] = true
  wa.log(string.format(
    "highlander: worm %d dealt %s (%s map)",
    worm.id, describe(arsenal:list(worm)), cave and "cavern" or "open"
  ))
end

local function start_turn(worm)
  arsenal:apply(worm, { clear = true, each = 1 })
  -- GiveWeapons: three Hot Air Balloons and a Wind Changer for the turn,
  -- whatever is left.
  worm:ammo("bungee", { set = 3 })
  worm:ammo("surrender", { set = 1 })
end

local function on_death(event)
  local victim = event.victim
  local active = event.active
  local mine = arsenal:list(victim)

  if active and active.id == victim.id then
    -- Died on its own turn: nothing to hand on, just take its weapons away.
    arsenal:clear(victim)
    arsenal:apply(victim, { clear = true, each = 1 })
    wa.log(string.format("highlander: worm %d died on its own turn", victim.id))
    return
  end

  -- Otherwise the worm whose turn it is gets everything -- whoever or
  -- whatever did the killing, friend or foe, exactly as in PX.
  if not active or active.hp <= 0 then
    return
  end
  arsenal:transfer(victim, active, { weapons = "all", mode = "move" })
  -- Usable at once, this turn, not from the stealer's next turn.
  arsenal:apply(active, { weapons = mine, each = 1 })
  wa.log(string.format(
    "highlander: worm %d took %s from worm %d",
    active.id, describe(mine), victim.id
  ))
end

wa.on.worm_message(function(worm, msg)
  if not dealt[worm.id] then
    deal(worm)
  end
end)

wa.on.turn_start(function(event)
  start_turn(event.worm)
end)

wa.on.death(on_death)
